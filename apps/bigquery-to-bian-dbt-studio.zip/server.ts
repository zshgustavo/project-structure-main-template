import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-loaded Gemini AI client helper
let aiClient: GoogleGenAI | null = null;
function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY environment variable is missing.");
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Local fallback mapping database for common financial columns when Gemini API Key is missing
const HEURISTIC_MAPPINGS: Record<string, { bian_column: string; bian_data_element: string; transformation_logic: string; description: string; domain: string }> = {
  id: { bian_column: "AccountIdentifier", bian_data_element: "Identifier", transformation_logic: "CAST(id AS STRING)", description: "Unique identifier for the financial account", domain: "Current Account" },
  account_id: { bian_column: "AccountIdentifier", bian_data_element: "Identifier", transformation_logic: "CAST(account_id AS STRING)", description: "Unique identifier for the account", domain: "Current Account" },
  cust_id: { bian_column: "CustomerID", bian_data_element: "Identifier", transformation_logic: "CAST(cust_id AS STRING)", description: "Unique identifier for the customer", domain: "Customer Agreement" },
  customer_id: { bian_column: "CustomerID", bian_data_element: "Identifier", transformation_logic: "CAST(customer_id AS STRING)", description: "Unique identifier for the customer", domain: "Customer Agreement" },
  balance: { bian_column: "AccountBalance", bian_data_element: "Amount", transformation_logic: "CAST(balance AS DECIMAL)", description: "The current outstanding balance", domain: "Current Account" },
  acct_bal: { bian_column: "AccountBalance", bian_data_element: "Amount", transformation_logic: "CAST(acct_bal AS DECIMAL)", description: "The current outstanding balance of the account", domain: "Current Account" },
  open_date: { bian_column: "OpeningDate", bian_data_element: "Date", transformation_logic: "CAST(open_date AS DATE)", description: "The date the account was opened", domain: "Current Account" },
  open_dt: { bian_column: "OpeningDate", bian_data_element: "Date", transformation_logic: "CAST(open_dt AS DATE)", description: "The date the account was created", domain: "Current Account" },
  status: { bian_column: "AccountStatus", bian_data_element: "Status", transformation_logic: "LOWER(status)", description: "Current operational status of the account", domain: "Current Account" },
  type: { bian_column: "AccountType", bian_data_element: "Text", transformation_logic: "UPPER(type)", description: "The product type of the account", domain: "Current Account" },
  acct_type: { bian_column: "AccountType", bian_data_element: "Text", transformation_logic: "UPPER(acct_type)", description: "The product type of the account", domain: "Current Account" },
  limit: { bian_column: "OverdraftLimit", bian_data_element: "Amount", transformation_logic: "CAST(limit AS DECIMAL)", description: "Overdraft limit or line of credit associated", domain: "Current Account" },
  credit_limit: { bian_column: "OverdraftLimit", bian_data_element: "Amount", transformation_logic: "CAST(credit_limit AS DECIMAL)", description: "Approved credit limit amount", domain: "Current Account" },
  first_name: { bian_column: "FirstName", bian_data_element: "Text", transformation_logic: "first_name", description: "First name of the customer", domain: "Customer Agreement" },
  last_name: { bian_column: "LastName", bian_data_element: "Text", transformation_logic: "last_name", description: "Last name of the customer", domain: "Customer Agreement" },
  email: { bian_column: "EmailAddress", bian_data_element: "Text", transformation_logic: "LOWER(email)", description: "Email contact address of the customer", domain: "Customer Agreement" },
  phone: { bian_column: "PhoneNumber", bian_data_element: "Text", transformation_logic: "phone", description: "Phone contact number of the customer", domain: "Customer Agreement" },
  address: { bian_column: "PostalAddress", bian_data_element: "Text", transformation_logic: "address", description: "Home postal address of the customer", domain: "Customer Agreement" },
  tx_id: { bian_column: "TransactionIdentifier", bian_data_element: "Identifier", transformation_logic: "CAST(tx_id AS STRING)", description: "Unique payment transaction identifier", domain: "Payment Execution" },
  amount: { bian_column: "TransactionAmount", bian_data_element: "Amount", transformation_logic: "CAST(amount AS DECIMAL)", description: "Amount transferred in the transaction", domain: "Payment Execution" },
  tx_amount: { bian_column: "TransactionAmount", bian_data_element: "Amount", transformation_logic: "CAST(tx_amount AS DECIMAL)", description: "Amount transferred in the transaction", domain: "Payment Execution" },
  currency: { bian_column: "CurrencyCode", bian_data_element: "Text", transformation_logic: "UPPER(currency)", description: "ISO code of the transaction currency", domain: "Payment Execution" },
  tx_date: { bian_column: "TransactionDate", bian_data_element: "Date", transformation_logic: "CAST(tx_date AS TIMESTAMP)", description: "Timestamp when transaction was executed", domain: "Payment Execution" },
  sender_id: { bian_column: "OriginatorAccountIdentifier", bian_data_element: "Identifier", transformation_logic: "CAST(sender_id AS STRING)", description: "Sender account identifier", domain: "Payment Execution" },
  receiver_id: { bian_column: "BeneficiaryAccountIdentifier", bian_data_element: "Identifier", transformation_logic: "CAST(receiver_id AS STRING)", description: "Receiver account identifier", domain: "Payment Execution" },
};

function getHeuristicMapping(colName: string, domain: string) {
  const norm = colName.toLowerCase().replace(/[^a-z0-9_]/g, "");
  if (HEURISTIC_MAPPINGS[norm]) {
    return {
      source_column: colName,
      source_type: "STRING",
      ...HEURISTIC_MAPPINGS[norm],
      confidence: "high"
    };
  }
  // Fallback heuristic renaming
  let cleanName = colName.split("_").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join("");
  return {
    source_column: colName,
    source_type: "STRING",
    bian_column: cleanName,
    bian_data_element: colName.includes("id") ? "Identifier" : colName.includes("date") || colName.includes("dt") ? "Date" : colName.includes("amount") || colName.includes("bal") ? "Amount" : "Text",
    transformation_logic: colName,
    bian_service_domain: domain || "Current Account",
    confidence: "medium",
    description: `Auto-mapped field for ${colName}`
  };
}

// 1. API: Map Schema using Gemini (or fallback)
app.post("/api/map-schema", async (req, res) => {
  const { columns, tableName, domain } = req.body;

  if (!columns || !Array.isArray(columns)) {
    return res.status(400).json({ error: "Columns array is required" });
  }

  const cleanTableName = tableName || "source_table";
  const cleanDomain = domain || "Current Account";

  try {
    const ai = getAiClient();
    console.log(`[API] Mapping columns using Gemini API for table ${cleanTableName} under BIAN domain ${cleanDomain}...`);
    
    const prompt = `
      You are an expert banking enterprise architect specializing in BIAN (Banking Industry Architecture Network) semantic standards and dbt Core SQL transformations.
      
      We have a BigQuery source table named "${cleanTableName}" belonging to the banking domain "${cleanDomain}".
      
      Map the following columns to BIAN canonical data names (CamelCase, no underscores, aligned with common BIAN banking models) and design the proper dbt/BigQuery SQL casting/cleansing transformation logic for each column.
      
      Source Columns:
      ${JSON.stringify(columns, null, 2)}
      
      For each column, provide:
      1. source_column: exact original column name
      2. source_type: approximate data type (STRING, INTEGER, FLOAT, TIMESTAMP, DATE, etc.)
      3. bian_column: standard BIAN CamelCase name (e.g., "AccountIdentifier", "CustomerReference", "AccountBalanceAmount", "TransactionExecutionDate")
      4. bian_data_element: BIAN-style core type (e.g., "Identifier", "Amount", "Date", "Text", "Status", "Code")
      5. transformation_logic: valid BigQuery SQL fragment to transform/cast this column (e.g., "CAST(acct_id AS STRING)", "SAFE_CAST(balance AS NUMERIC)", "PARSE_TIMESTAMP('%Y-%m-%d', date_str)")
      6. bian_service_domain: the most applicable BIAN Service Domain (e.g., "Current Account", "Customer Agreement", "Payment Execution", "Savings Account")
      7. confidence: "high", "medium", or "low"
      8. description: a short description of the element and how it aligns to BIAN.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              source_column: { type: Type.STRING },
              source_type: { type: Type.STRING },
              bian_column: { type: Type.STRING },
              bian_data_element: { type: Type.STRING },
              transformation_logic: { type: Type.STRING },
              bian_service_domain: { type: Type.STRING },
              confidence: { type: Type.STRING },
              description: { type: Type.STRING }
            },
            required: ["source_column", "bian_column", "transformation_logic", "bian_service_domain"]
          }
        }
      }
    });

    const resultText = response.text || "[]";
    const mapped = JSON.parse(resultText);
    res.json({ mappings: mapped, method: "gemini-api" });

  } catch (err: any) {
    console.warn("[API] Gemini API mapping failed or is not available. Using local rule-based heuristic mapper.", err.message);
    
    // Perform heuristic mapping as fallback
    const mapped = columns.map((col: any) => {
      const colName = typeof col === "string" ? col : col.name;
      const colType = typeof col === "string" ? "STRING" : col.type || "STRING";
      const heuristic = getHeuristicMapping(colName, cleanDomain);
      return {
        ...heuristic,
        source_type: colType
      };
    });

    res.json({
      mappings: mapped,
      method: "heuristics",
      warning: "Gemini API mapping was not available, rule-based heuristics were applied."
    });
  }
});

// 2. API: Simulate Pipeline Run
app.post("/api/simulate-pipeline", (req, res) => {
  const { action, table, mappings, datasetSource, datasetDest, gcpProject } = req.body;

  if (!action) {
    return res.status(400).json({ error: "Action is required ('compile', 'test', 'publish')" });
  }

  const logs: string[] = [];
  const addLog = (msg: string) => {
    const timestamp = new Date().toISOString().replace("T", " ").substring(0, 19);
    logs.push(`[${timestamp}] ${msg}`);
  };

  const proj = gcpProject || "gcp-finance-prod";
  const srcDataset = datasetSource || "core_banking_raw";
  const destDataset = datasetDest || "bian_standardized";
  const srcTable = table || "savings_accounts";

  addLog(`Initiating dbt-core pipeline action: [${action.toUpperCase()}]`);
  addLog(`Configuring Google Cloud SDK credentials (ADC)...`);
  addLog(`Target project: '${proj}' | Region: 'us-east1'`);

  if (action === "compile" || action === "test" || action === "publish") {
    addLog(`Loading profiles.yml configuration...`);
    addLog(`Profile 'bian_pipeline' matches type 'bigquery' using auth method 'oauth'`);
    addLog(`Scanning dbt project directory './dbt/'...`);
    addLog(`Found 1 source database defined: '${proj}.${srcDataset}'`);
    addLog(`Found 2 dbt models: 'stg_${srcTable}.sql', '${srcTable}__bian.sql'`);
    addLog(`Beginning dbt semantic parsing and model compilation...`);
  }

  if (action === "compile") {
    addLog(`Compiling model: 'stg_${srcTable}'`);
    addLog(`SQL compiled successfully (compiled query length: ${950 + mappings.length * 40} bytes)`);
    addLog(`Compiling BIAN-aligned model: '${srcTable}__bian'`);
    addLog(`dbt compilation completed. Target artifacts updated in './target/compiled/'`);
    addLog(`Validation checklist:`);
    addLog(`  ✔ Sources verified against BigQuery schema catalogue`);
    addLog(`  ✔ CamelCase BIAN name compliance verified`);
    addLog(`  ✔ BigQuery datatype compatibility check passed`);
    addLog(`STATUS: SUCCESS. Pipeline compiled and ready for dbt run.`);
  } else if (action === "test") {
    addLog(`Executing validation suite for 'stg_${srcTable}' and '${srcTable}__bian'`);
    addLog(`Running test 'unique' on '${srcTable}__bian' field 'AccountIdentifier'`);
    addLog(`  └─ Query: SELECT AccountIdentifier FROM ${proj}.${destDataset}.${srcTable}__bian GROUP BY 1 HAVING COUNT(*) > 1`);
    addLog(`  └─ RESULT: 0 records found (PASS)`);
    addLog(`Running test 'not_null' on '${srcTable}__bian' field 'AccountIdentifier'`);
    addLog(`  └─ RESULT: 0 records found (PASS)`);
    addLog(`Running custom BIAN structural verification...`);
    addLog(`  ✔ Schema matches BIAN standard for Service Domain: 'Current Account'`);
    addLog(`STATUS: SUCCESS. 3 tests executed, 3 passed.`);
  } else if (action === "publish") {
    addLog(`Starting Jenkins continuous deployment executor pipeline...`);
    addLog(`Jenkins Job ID: #104 | Workspace: '/var/jenkins_home/workspace/bian-migration'`);
    addLog(`Executing: python migrate.py --action publish --project ${proj} --src-dataset ${srcDataset} --dest-dataset ${destDataset} --table ${srcTable}`);
    addLog(`[dbt-run] Materializing BIAN model as VIEW/TABLE in BigQuery...`);
    addLog(`[BigQuery API] Creating target table if not exists: '${proj}.${destDataset}.${srcTable}__bian'`);
    addLog(`[BigQuery API] Running SQL Query to insert/overwrite materialized data...`);
    
    // Simulate query execution details
    addLog(`[BigQuery Job] Job ID: job_7a82b0f9_bc44_41c0 | Status: RUNNING`);
    addLog(`[BigQuery Job] Stage 1 (Input/Scan): Read ${mappings.length} columns from ${proj}.${srcDataset}.${srcTable}`);
    addLog(`[BigQuery Job] Stage 2 (Transform/Cast): Processed 42,910 rows in 1.4 seconds`);
    addLog(`[BigQuery Job] Stage 3 (Output): Materialized 42,910 rows into table ${proj}.${destDataset}.${srcTable}__bian`);
    addLog(`[BigQuery Job] Bytes Billed: 5.42 MB | Slots used: 22`);
    addLog(`[dbt-run] Materialization completed successfully.`);
    addLog(`Publish action completed. BIAN data successfully synchronized.`);
    addLog(`STATUS: SUCCESS. Production table updated.`);
  }

  res.json({ logs });
});

// Serve health status
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", port: PORT, geminiEnabled: !!process.env.GEMINI_API_KEY });
});

// Start Vite dev server in development, serve static in production
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Server] BigQuery to BIAN Studio running on port ${PORT}`);
  });
}

startServer();
