import React from "react";
import { ConnectionConfig, ColumnDef } from "../types";
import { TABLE_TEMPLATES, TableTemplate } from "../data/templates";
import { Database, ShieldAlert, Key, Plus, Trash2, LayoutGrid, CheckCircle } from "lucide-react";

interface ConnectionConfigProps {
  config: ConnectionConfig;
  onChangeConfig: (newConfig: ConnectionConfig) => void;
  columns: ColumnDef[];
  onChangeColumns: (newCols: ColumnDef[]) => void;
  activeTemplateId: string;
  onSelectTemplate: (template: TableTemplate) => void;
  selectedDomain: string;
  onChangeDomain: (domain: string) => void;
}

const BIAN_SERVICE_DOMAINS = [
  "Current Account",
  "Customer Agreement",
  "Payment Execution",
  "Savings Account",
  "Customer Profile",
  "Corporate Agreement",
  "Credit Facility"
];

export default function ConnectionConfigPanel({
  config,
  onChangeConfig,
  columns,
  onChangeColumns,
  activeTemplateId,
  onSelectTemplate,
  selectedDomain,
  onChangeDomain,
}: ConnectionConfigProps) {
  const [newColName, setNewColName] = React.useState("");
  const [newColType, setNewColType] = React.useState("STRING");

  const handleTextChange = (field: keyof ConnectionConfig, value: string) => {
    onChangeConfig({
      ...config,
      [field]: value,
    });
  };

  const handleCredentialsTypeChange = (type: "adc" | "service_account") => {
    onChangeConfig({
      ...config,
      credentialsType: type,
    });
  };

  const handleAddColumn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newColName.trim()) return;
    const normName = newColName.trim().toLowerCase().replace(/[^a-z0-9_]/g, "_");
    if (columns.some((c) => c.name === normName)) {
      alert("Column already exists!");
      return;
    }
    const newCols = [...columns, { name: normName, type: newColType, description: `Custom column added dynamically.` }];
    onChangeColumns(newCols);
    setNewColName("");
  };

  const handleRemoveColumn = (index: number) => {
    const newCols = columns.filter((_, i) => i !== index);
    onChangeColumns(newCols);
  };

  return (
    <div id="connection-config-panel" className="space-y-6">
      {/* 1. Templates Selection */}
      <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs">
        <div className="flex items-center gap-2 mb-3">
          <LayoutGrid className="w-5 h-5 text-indigo-600" />
          <h2 className="text-sm font-semibold text-slate-900 uppercase tracking-wider">
            1. Select Table Template
          </h2>
        </div>
        <p className="text-xs text-slate-500 mb-4">
          Choose a pre-built legacy financial schema to instantly populate the pipeline workspace:
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {TABLE_TEMPLATES.map((tmpl) => {
            const isActive = activeTemplateId === tmpl.id;
            return (
              <button
                key={tmpl.id}
                type="button"
                id={`btn-template-${tmpl.id}`}
                onClick={() => onSelectTemplate(tmpl)}
                className={`p-3 text-left rounded-lg border transition-all text-xs duration-200 cursor-pointer flex flex-col justify-between h-28 ${
                  isActive
                    ? "bg-indigo-50/50 border-indigo-400 ring-2 ring-indigo-100"
                    : "bg-slate-50 border-slate-200 hover:bg-slate-100"
                }`}
              >
                <div>
                  <div className="font-semibold text-slate-800 flex items-center justify-between">
                    {tmpl.name}
                    {isActive && <CheckCircle className="w-4 h-4 text-indigo-600" />}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
                    {tmpl.description}
                  </p>
                </div>
                <div className="text-[10px] text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-sm self-start font-medium border border-indigo-100 mt-2">
                  {tmpl.defaultDomain}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. GCP Settings */}
      <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs">
        <div className="flex items-center gap-2 mb-4">
          <Database className="w-5 h-5 text-indigo-600" />
          <h2 className="text-sm font-semibold text-slate-900 uppercase tracking-wider">
            2. BigQuery Connection Settings
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              GCP Project ID
            </label>
            <input
              type="text"
              id="gcp-project-input"
              value={config.gcpProject}
              onChange={(e) => handleTextChange("gcpProject", e.target.value)}
              placeholder="e.g. core-banking-production"
              className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              BIAN Service Domain Target
            </label>
            <select
              id="bian-domain-select"
              value={selectedDomain}
              onChange={(e) => onChangeDomain(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white"
            >
              {BIAN_SERVICE_DOMAINS.map((domain) => (
                <option key={domain} value={domain}>
                  {domain}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Source Table Name
            </label>
            <input
              type="text"
              id="table-name-input"
              value={config.tableName}
              onChange={(e) => handleTextChange("tableName", e.target.value)}
              placeholder="e.g. legacy_savings_accounts"
              className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Source Dataset
              </label>
              <input
                type="text"
                id="dataset-source-input"
                value={config.datasetSource}
                onChange={(e) => handleTextChange("datasetSource", e.target.value)}
                placeholder="e.g. core_raw"
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Destination Dataset
              </label>
              <input
                type="text"
                id="dataset-dest-input"
                value={config.datasetDest}
                onChange={(e) => handleTextChange("datasetDest", e.target.value)}
                placeholder="e.g. bian_standardized"
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white"
              />
            </div>
          </div>
        </div>

        {/* Credentials Tab */}
        <div className="mt-5 pt-4 border-t border-slate-100">
          <label className="block text-xs font-semibold text-slate-700 mb-2">
            Authentication Method
          </label>
          <div className="grid grid-cols-2 gap-2 mb-3">
            <button
              type="button"
              id="btn-auth-adc"
              onClick={() => handleCredentialsTypeChange("adc")}
              className={`py-2 px-3 text-xs rounded-lg border font-medium cursor-pointer ${
                config.credentialsType === "adc"
                  ? "bg-slate-900 border-slate-900 text-white"
                  : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
              }`}
            >
              Application Default Credentials (ADC)
            </button>
            <button
              type="button"
              id="btn-auth-sa"
              onClick={() => handleCredentialsTypeChange("service_account")}
              className={`py-2 px-3 text-xs rounded-lg border font-medium cursor-pointer ${
                config.credentialsType === "service_account"
                  ? "bg-slate-900 border-slate-900 text-white"
                  : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
              }`}
            >
              Service Account Key JSON
            </button>
          </div>

          {config.credentialsType === "service_account" && (
            <div className="space-y-3 bg-slate-50 p-3 rounded-lg border border-slate-200 animate-fadeIn">
              <div>
                <label className="block text-[10px] font-semibold text-slate-600 mb-1">
                  Service Account Email
                </label>
                <input
                  type="text"
                  id="sa-email-input"
                  value={config.saEmail}
                  onChange={(e) => handleTextChange("saEmail", e.target.value)}
                  placeholder="e.g. dbt-runner@finance-prod.iam.gserviceaccount.com"
                  className="w-full text-xs bg-white border border-slate-200 rounded-md px-2.5 py-1.5 text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-[10px] font-semibold text-slate-600 mb-1">
                  Target Jenkins Path to Keyfile
                </label>
                <input
                  type="text"
                  id="sa-key-file-input"
                  value={config.saKeyFile}
                  onChange={(e) => handleTextChange("saKeyFile", e.target.value)}
                  placeholder="/var/jenkins_home/secrets/gcp-sa-key.json"
                  className="w-full text-xs bg-white border border-slate-200 rounded-md px-2.5 py-1.5 text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 3. Schema Catalog Columns list */}
      <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Key className="w-5 h-5 text-indigo-600" />
            <h2 className="text-sm font-semibold text-slate-900 uppercase tracking-wider">
              3. Source Schema Catalog
            </h2>
          </div>
          <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
            {columns.length} columns
          </span>
        </div>
        <p className="text-xs text-slate-500 mb-4">
          Manipulate source columns or insert custom fields for dbt schema alignment:
        </p>

        {/* Dynamic Column Addition Form */}
        <form onSubmit={handleAddColumn} className="flex gap-2 mb-4">
          <input
            type="text"
            id="new-col-name-input"
            value={newColName}
            onChange={(e) => setNewColName(e.target.value)}
            placeholder="Add field name (e.g. credit_score)"
            className="flex-1 text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 focus:bg-white"
          />
          <select
            id="new-col-type-select"
            value={newColType}
            onChange={(e) => setNewColType(e.target.value)}
            className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-slate-800 focus:outline-hidden"
          >
            <option value="STRING">STRING</option>
            <option value="INTEGER">INTEGER</option>
            <option value="NUMERIC">NUMERIC</option>
            <option value="DATE">DATE</option>
            <option value="TIMESTAMP">TIMESTAMP</option>
            <option value="BOOLEAN">BOOLEAN</option>
          </select>
          <button
            type="submit"
            id="btn-add-custom-column"
            className="p-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg flex items-center justify-center transition-colors cursor-pointer"
            title="Add column"
          >
            <Plus className="w-4 h-4" />
          </button>
        </form>

        {/* Columns Grid */}
        <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
          {columns.map((col, idx) => (
            <div
              key={`${col.name}-${idx}`}
              className="flex items-center justify-between p-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-xs"
            >
              <div className="flex items-center gap-2">
                <span className="font-mono text-slate-700 font-semibold">{col.name}</span>
                <span className="text-[10px] bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded-sm uppercase tracking-wider font-mono">
                  {col.type}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-slate-500 max-w-[180px] truncate" title={col.description}>
                  {col.description}
                </span>
                <button
                  type="button"
                  id={`btn-remove-col-${col.name}`}
                  onClick={() => handleRemoveColumn(idx)}
                  className="p-1 text-slate-400 hover:text-red-500 transition-colors cursor-pointer"
                  title="Delete column"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
          {columns.length === 0 && (
            <div className="text-center py-6 border-2 border-dashed border-slate-200 rounded-lg text-slate-400 text-xs">
              No columns in the source catalog. Select a template or insert custom columns above.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
