import React from "react";
import { ColumnDef, BianMapping } from "../types";
import { Sparkles, ArrowRight, CheckCircle2, AlertCircle, Edit, Info, AlertTriangle, ShieldCheck } from "lucide-react";

interface MappingBoardProps {
  columns: ColumnDef[];
  mappings: BianMapping[];
  onChangeMappings: (newMappings: BianMapping[]) => void;
  tableName: string;
  selectedDomain: string;
}

export default function MappingBoard({
  columns,
  mappings,
  onChangeMappings,
  tableName,
  selectedDomain,
}: MappingBoardProps) {
  const [isMappingAI, setIsMappingAI] = React.useState(false);
  const [mappingStatus, setMappingStatus] = React.useState<"idle" | "success" | "heuristics" | "failed">("idle");
  const [aiMethod, setAiMethod] = React.useState("");

  const runAiMapping = async () => {
    if (columns.length === 0) {
      alert("Please add columns to your source schema catalog before auto-mapping.");
      return;
    }

    setIsMappingAI(true);
    setMappingStatus("idle");

    try {
      const response = await fetch("/api/map-schema", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          columns: columns,
          tableName: tableName,
          domain: selectedDomain,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to map schema via server API");
      }

      const data = await response.json();
      if (data.mappings && Array.isArray(data.mappings)) {
        onChangeMappings(data.mappings);
        if (data.method === "gemini-api") {
          setMappingStatus("success");
          setAiMethod("Gemini 3.6 Flash");
        } else {
          setMappingStatus("heuristics");
          setAiMethod("Local Banking Heuristics (Gemini Key not configured)");
        }
      } else {
        throw new Error("Invalid response format");
      }
    } catch (err) {
      console.error(err);
      setMappingStatus("failed");
    } finally {
      setIsMappingAI(false);
    }
  };

  const handleFieldChange = (index: number, key: keyof BianMapping, value: any) => {
    const newMappings = [...mappings];
    newMappings[index] = {
      ...newMappings[index],
      [key]: value,
    };
    onChangeMappings(newMappings);
  };

  // Automatically trigger heuristic pre-mapping on mount if mappings are empty but columns exist
  React.useEffect(() => {
    if (mappings.length === 0 && columns.length > 0) {
      // Local rule-based pre-population so the board isn't empty initially
      const initialMappings: BianMapping[] = columns.map((col) => {
        const norm = col.name.toLowerCase().replace(/[^a-z0-9_]/g, "");
        let cleanName = col.name.split("_").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join("");
        
        // Logical guesses
        let bianCol = cleanName;
        let element: BianMapping["bian_data_element"] = "Text";
        let sql = `\`${col.name}\``;

        if (norm === "id" || norm === "account_id") {
          bianCol = "AccountIdentifier";
          element = "Identifier";
          sql = `CAST(\`${col.name}\` AS STRING)`;
        } else if (norm === "cust_id" || norm === "customer_id") {
          bianCol = "CustomerID";
          element = "Identifier";
          sql = `CAST(\`${col.name}\` AS STRING)`;
        } else if (norm.includes("bal") || norm.includes("amount") || norm.includes("limit")) {
          element = "Amount";
          sql = `SAFE_CAST(\`${col.name}\` AS NUMERIC)`;
        } else if (norm.includes("date") || norm.includes("dt") || norm.includes("time")) {
          element = "Date";
          sql = col.type === "TIMESTAMP" ? `\`${col.name}\`` : `PARSE_DATE('%Y-%m-%d', \`${col.name}\`)`;
        } else if (norm === "status") {
          element = "Status";
          sql = `LOWER(\`${col.name}\`)`;
        } else if (norm === "type") {
          element = "Code";
        }

        return {
          source_column: col.name,
          source_type: col.type,
          bian_column: bianCol,
          bian_data_element: element,
          transformation_logic: sql,
          bian_service_domain: selectedDomain,
          confidence: "medium",
          description: `Standardized BIAN field for legacy ${col.name}`
        };
      });
      onChangeMappings(initialMappings);
    }
  }, [columns, selectedDomain, mappings.length, onChangeMappings]);

  return (
    <div id="mapping-board-panel" className="space-y-4">
      {/* AI Controls Header */}
      <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-amber-500 fill-amber-500" />
            AI Schema Alignment & Mapping board
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Standardize your BigQuery schema fields to the unified BIAN structures using Gemini cognitive standard models or custom transformations.
          </p>
        </div>

        <button
          type="button"
          id="btn-run-ai-mapping"
          onClick={runAiMapping}
          disabled={isMappingAI || columns.length === 0}
          className={`flex items-center gap-2 py-2 px-4 rounded-lg text-xs font-semibold shadow-xs transition-all cursor-pointer ${
            isMappingAI
              ? "bg-indigo-100 text-indigo-400 cursor-not-allowed"
              : "bg-indigo-600 hover:bg-indigo-700 text-white"
          }`}
        >
          {isMappingAI ? (
            <>
              <div className="w-4 h-4 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin" />
              <span>Mapping schema...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>Auto-Map to BIAN with AI</span>
            </>
          )}
        </button>
      </div>

      {/* AI Success / Fallback Status Notification */}
      {mappingStatus === "success" && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-2.5 rounded-lg flex items-center gap-2 text-xs">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>
            <strong>Success:</strong> Aligned successfully via <strong>{aiMethod}</strong>! BigQuery SQL castings and BIAN CamelCase representations resolved.
          </span>
        </div>
      )}
      {mappingStatus === "heuristics" && (
        <div className="bg-amber-50 border border-amber-200 text-amber-800 px-4 py-2.5 rounded-lg flex items-start gap-2 text-xs">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <strong>Rule-Based Standard Mapping Applied:</strong> We generated BIAN-aligned specifications using local financial rules. Set up your <strong>GEMINI_API_KEY</strong> in the Secrets menu to unlock advanced semantic translation.
          </div>
        </div>
      )}
      {mappingStatus === "failed" && (
        <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-2.5 rounded-lg flex items-center gap-2 text-xs">
          <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
          <span>
            <strong>Error:</strong> Failed to reach Gemini API backend. Applied heuristics fallback instead.
          </span>
        </div>
      )}

      {/* Columns Mapping List */}
      <div className="space-y-3">
        {mappings.map((m, idx) => {
          const confColors = {
            high: "bg-emerald-50 text-emerald-700 border-emerald-100",
            medium: "bg-indigo-50 text-indigo-700 border-indigo-100",
            low: "bg-amber-50 text-amber-700 border-amber-100",
          };

          return (
            <div
              key={`${m.source_column}-mapping-${idx}`}
              className="bg-white border border-slate-100 rounded-xl p-4 shadow-xs hover:border-slate-200 transition-all grid grid-cols-1 lg:grid-cols-12 gap-4 items-center"
            >
              {/* Left Side: Source Column */}
              <div className="lg:col-span-3 flex items-center gap-2.5 border-r lg:border-r-slate-100 pr-2">
                <div className="bg-slate-50 p-2 rounded-lg border border-slate-200 text-center min-w-[50px]">
                  <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">
                    Source
                  </span>
                  <span className="font-mono text-[10px] text-slate-500 font-semibold uppercase">
                    {m.source_type}
                  </span>
                </div>
                <div className="truncate">
                  <h4 className="font-mono text-xs font-bold text-slate-800 truncate" title={m.source_column}>
                    {m.source_column}
                  </h4>
                  <p className="text-[10px] text-slate-400 truncate">
                    BigQuery original field
                  </p>
                </div>
              </div>

              {/* Center Icon */}
              <div className="hidden lg:flex lg:col-span-1 justify-center">
                <ArrowRight className="w-4 h-4 text-slate-400" />
              </div>

              {/* Right Side Fields: Mapped BIAN Columns & Edit Controls */}
              <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-3">
                {/* BIAN Target Name */}
                <div className="lg:col-span-4">
                  <label className="block text-[10px] font-semibold text-slate-500 mb-0.5">
                    BIAN Target Name (CamelCase)
                  </label>
                  <input
                    type="text"
                    id={`input-bian-col-${m.source_column}`}
                    value={m.bian_column}
                    onChange={(e) => handleFieldChange(idx, "bian_column", e.target.value)}
                    className="w-full text-xs font-semibold bg-slate-50 border border-slate-200 rounded-md px-2 py-1.5 text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 focus:bg-white"
                  />
                </div>

                {/* BIAN Data Element Type */}
                <div className="lg:col-span-3">
                  <label className="block text-[10px] font-semibold text-slate-500 mb-0.5">
                    BIAN Data Element
                  </label>
                  <select
                    id={`select-bian-element-${m.source_column}`}
                    value={m.bian_data_element}
                    onChange={(e) => handleFieldChange(idx, "bian_data_element", e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-md px-2 py-1.5 text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value="Identifier">Identifier</option>
                    <option value="Amount">Amount</option>
                    <option value="Date">Date</option>
                    <option value="Text">Text</option>
                    <option value="Status">Status</option>
                    <option value="Code">Code</option>
                  </select>
                </div>

                {/* SQL Cast expression */}
                <div className="lg:col-span-5">
                  <label className="block text-[10px] font-semibold text-slate-500 mb-0.5 flex justify-between items-center">
                    <span>BigQuery Casting SQL</span>
                    <span className={`text-[9px] px-1 rounded-sm border ${confColors[m.confidence] || "bg-slate-50"}`}>
                      {m.confidence} match
                    </span>
                  </label>
                  <input
                    type="text"
                    id={`input-bian-sql-${m.source_column}`}
                    value={m.transformation_logic}
                    onChange={(e) => handleFieldChange(idx, "transformation_logic", e.target.value)}
                    className="w-full text-xs font-mono bg-slate-50 border border-slate-200 rounded-md px-2 py-1.5 text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 focus:bg-white"
                  />
                </div>

                {/* Description Inline row */}
                <div className="md:col-span-2 lg:col-span-12">
                  <input
                    type="text"
                    id={`input-bian-desc-${m.source_column}`}
                    value={m.description}
                    onChange={(e) => handleFieldChange(idx, "description", e.target.value)}
                    placeholder="Provide a BIAN semantic description..."
                    className="w-full text-[11px] bg-transparent text-slate-500 border-b border-dashed border-slate-100 hover:border-slate-300 focus:border-indigo-500 focus:outline-hidden py-0.5"
                  />
                </div>
              </div>
            </div>
          );
        })}

        {mappings.length === 0 && (
          <div className="text-center py-10 bg-white border border-dashed border-slate-200 rounded-xl text-slate-400 text-xs">
            No active column mapping configurations. Add fields or load templates in the Left panel first.
          </div>
        )}
      </div>
    </div>
  );
}
