import React from "react";
import { ConnectionConfig, BianMapping } from "../types";
import {
  generateDbtProjectYml,
  generateProfilesYml,
  generateSourcesYml,
  generateStagingSql,
  generateBianSql,
  generateSchemaYml,
  generateMigratePy,
  generateJenkinsfile,
} from "../utils/codeGenerators";
import { FileCode, Copy, Check, Download, FolderOpen, Terminal } from "lucide-react";

interface CodeExporterProps {
  config: ConnectionConfig;
  mappings: BianMapping[];
}

export default function CodeExporter({ config, mappings }: CodeExporterProps) {
  const [activeTab, setActiveTab] = React.useState<string>("migrate.py");
  const [copied, setCopied] = React.useState<boolean>(false);

  const files = React.useMemo(() => {
    const table = config.tableName || "legacy_savings_accounts";
    return [
      {
        name: "migrate.py",
        lang: "python",
        path: "./migrate.py",
        description: "Python CLI entrypoint to validate schemas, authorize BigQuery, and execute dbt steps.",
        content: generateMigratePy(config, mappings),
      },
      {
        name: `stg_${table}.sql`,
        lang: "sql",
        path: `./dbt/models/staging/stg_${table}.sql`,
        description: "dbt view that casts legacy formats and maps columns to CamelCase BIAN properties.",
        content: generateStagingSql(config, mappings),
      },
      {
        name: `${table}__bian.sql`,
        lang: "sql",
        path: `./dbt/models/bian/${table}__bian.sql`,
        description: "Final core model compiling standardized reporting tables.",
        content: generateBianSql(config, mappings),
      },
      {
        name: "sources.yml",
        lang: "yaml",
        path: "./dbt/models/sources.yml",
        description: "Schema model documentation for original BigQuery input sources.",
        content: generateSourcesYml(config, mappings),
      },
      {
        name: "schema.yml",
        lang: "yaml",
        path: "./dbt/models/schema.yml",
        description: "Tests and constraint definitions (unique, not_null) for output fields.",
        content: generateSchemaYml(config, mappings),
      },
      {
        name: "dbt_project.yml",
        lang: "yaml",
        path: "./dbt/dbt_project.yml",
        description: "Local dbt project setup configuration.",
        content: generateDbtProjectYml(),
      },
      {
        name: "profiles.yml",
        lang: "yaml",
        path: "./dbt/profiles.yml",
        description: "Local credentials and target BigQuery dataset profile connections.",
        content: generateProfilesYml(config),
      },
      {
        name: "Jenkinsfile",
        lang: "groovy",
        path: "./Jenkinsfile",
        description: "CI/CD declarative configuration to automate testing and publishing steps on branches.",
        content: generateJenkinsfile(config),
      },
    ];
  }, [config, mappings]);

  const activeFile = files.find((f) => f.name === activeTab) || files[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([activeFile.content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = activeFile.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div id="code-exporter-panel" className="bg-slate-900 rounded-xl border border-slate-800 text-slate-100 overflow-hidden shadow-lg">
      {/* File browser header */}
      <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FolderOpen className="w-5 h-5 text-indigo-400" />
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Pipeline Scaffold Tree
          </span>
        </div>
        <div className="flex items-center gap-2">
          {/* Copy Button */}
          <button
            type="button"
            id="btn-copy-code"
            onClick={handleCopy}
            className="flex items-center gap-1 text-[11px] bg-slate-800 hover:bg-slate-700 text-slate-200 py-1 px-2.5 rounded-md font-semibold transition-colors cursor-pointer"
            title="Copy file contents"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy</span>
              </>
            )}
          </button>

          {/* Download Button */}
          <button
            type="button"
            id="btn-download-file"
            onClick={handleDownload}
            className="flex items-center gap-1 text-[11px] bg-indigo-600 hover:bg-indigo-700 text-white py-1 px-2.5 rounded-md font-semibold transition-colors cursor-pointer"
            title="Download file"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download</span>
          </button>
        </div>
      </div>

      {/* Tabs list & Content */}
      <div className="grid grid-cols-1 md:grid-cols-4 min-h-[420px]">
        {/* Left Side: Tree browser */}
        <div className="bg-slate-950/40 p-3 border-r border-slate-800 space-y-1">
          <span className="block text-[10px] font-bold text-slate-500 uppercase px-2 mb-2">
            Files ({files.length})
          </span>
          {files.map((file) => {
            const isActive = activeTab === file.name;
            const isSql = file.name.endsWith(".sql");
            const isPy = file.name.endsWith(".py");
            const isYml = file.name.endsWith(".yml");

            return (
              <button
                key={file.name}
                type="button"
                id={`tab-file-${file.name}`}
                onClick={() => {
                  setActiveTab(file.name);
                  setCopied(false);
                }}
                className={`w-full text-left py-1.5 px-3 rounded-md text-xs font-mono transition-all flex items-center justify-between cursor-pointer ${
                  isActive
                    ? "bg-slate-800 text-indigo-400 font-bold border-l-2 border-indigo-500 pl-2.5"
                    : "text-slate-400 hover:bg-slate-900 hover:text-slate-200"
                }`}
              >
                <span className="truncate flex items-center gap-1.5">
                  <FileCode className={`w-3.5 h-3.5 shrink-0 ${isSql ? "text-blue-400" : isPy ? "text-amber-400" : isYml ? "text-emerald-400" : "text-slate-400"}`} />
                  {file.name}
                </span>
              </button>
            );
          })}
        </div>

        {/* Right Side: Code viewer */}
        <div className="md:col-span-3 p-4 flex flex-col justify-between bg-slate-900/40">
          <div>
            {/* File Path info */}
            <div className="flex items-center justify-between bg-slate-950/60 rounded-lg py-1.5 px-3 border border-slate-800 mb-3 text-[10px] font-mono text-slate-400">
              <span className="truncate">{activeFile.path}</span>
              <span className="text-[9px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded-sm uppercase font-semibold">
                {activeFile.lang}
              </span>
            </div>
            {/* Short description */}
            <p className="text-xs text-slate-400 mb-4 bg-slate-950/30 p-2.5 border-l-2 border-indigo-500/50 rounded-r-md italic">
              {activeFile.description}
            </p>
            {/* Code Content */}
            <div className="relative overflow-x-auto max-h-[350px] font-mono text-xs text-slate-300 bg-slate-950 p-4 rounded-lg border border-slate-850 shadow-inner scrollbar-thin scrollbar-thumb-slate-800">
              <pre className="whitespace-pre">
                <code>{activeFile.content}</code>
              </pre>
            </div>
          </div>

          <div className="text-[10px] text-slate-500 mt-4 flex items-center gap-1 bg-slate-950/20 p-2 rounded-md">
            <Terminal className="w-3.5 h-3.5 text-slate-400" />
            <span>These files update dynamically as you configure connections and mapping criteria.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
