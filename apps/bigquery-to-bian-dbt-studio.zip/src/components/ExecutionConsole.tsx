import React from "react";
import { ConnectionConfig, BianMapping, PipelineStage } from "../types";
import { Play, CheckCircle2, Terminal, AlertTriangle, RotateCcw, Activity, ShieldCheck, PlayCircle } from "lucide-react";

interface ExecutionConsoleProps {
  config: ConnectionConfig;
  mappings: BianMapping[];
}

export default function ExecutionConsole({ config, mappings }: ExecutionConsoleProps) {
  const [isRunning, setIsRunning] = React.useState<boolean>(false);
  const [activeAction, setActiveAction] = React.useState<"compile" | "test" | "publish" | null>(null);
  const [consoleLogs, setConsoleLogs] = React.useState<string[]>([]);
  const [stages, setStages] = React.useState<PipelineStage[]>([
    { id: "auth", name: "GCP Authentication Check", status: "idle" },
    { id: "schema", name: "BigQuery Source Verification", status: "idle" },
    { id: "compile", name: "dbt Compilation", status: "idle" },
    { id: "test", name: "dbt Quality Tests", status: "idle" },
    { id: "publish", name: "Production BIAN Publish", status: "idle" },
  ]);

  const runPipelineAction = async (action: "compile" | "test" | "publish") => {
    setIsRunning(true);
    setActiveAction(action);
    setConsoleLogs((prev) => [...prev, `\n>>> INITIATING PIPELINE ACTION: [${action.toUpperCase()}] ...`]);

    // Set initial running stages
    setStages((prev) =>
      prev.map((s, idx) => {
        if (idx === 0) return { ...s, status: "running" };
        return { ...s, status: "idle" };
      })
    );

    try {
      // Simulate sequential stage transitions for high-fidelity UI feedback
      const response = await fetch("/api/simulate-pipeline", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action,
          table: config.tableName,
          mappings,
          datasetSource: config.datasetSource,
          datasetDest: config.datasetDest,
          gcpProject: config.gcpProject,
        }),
      });

      if (!response.ok) {
        throw new Error("Simulation server failed to respond");
      }

      const data = await response.json();
      const logsToAppend = data.logs || [];

      // Step by step visual trigger of stages
      const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

      // Auth Stage
      await sleep(1000);
      setStages((prev) =>
        prev.map((s) => (s.id === "auth" ? { ...s, status: "success", duration: "1.1s" } : s.id === "schema" ? { ...s, status: "running" } : s))
      );

      // Schema Stage
      await sleep(1200);
      setStages((prev) =>
        prev.map((s) => (s.id === "schema" ? { ...s, status: "success", duration: "1.3s" } : s.id === "compile" ? { ...s, status: "running" } : s))
      );

      // Compile Stage
      await sleep(1400);
      const isCompileSucc = true;
      setStages((prev) =>
        prev.map((s) => {
          if (s.id === "compile") {
            return { ...s, status: isCompileSucc ? "success" : "failed", duration: "2.4s" };
          }
          if (action === "test" || action === "publish") {
            if (s.id === "test") return { ...s, status: "running" };
          }
          return s;
        })
      );

      if (action === "test" || action === "publish") {
        // Test Stage
        await sleep(1500);
        setStages((prev) =>
          prev.map((s) => {
            if (s.id === "test") {
              return { ...s, status: "success", duration: "2.1s" };
            }
            if (action === "publish" && s.id === "publish") {
              return { ...s, status: "running" };
            }
            return s;
          })
        );
      }

      if (action === "publish") {
        // Publish Stage
        await sleep(1800);
        setStages((prev) =>
          prev.map((s) => (s.id === "publish" ? { ...s, status: "success", duration: "3.2s" } : s))
        );
      }

      // Finally append all backend logs
      setConsoleLogs((prev) => [...prev, ...logsToAppend]);

    } catch (err: any) {
      setConsoleLogs((prev) => [...prev, `[❌ ERR] Simulation crashed: ${err.message}`]);
      setStages((prev) => prev.map((s) => (s.status === "running" ? { ...s, status: "failed" } : s)));
    } finally {
      setIsRunning(false);
    }
  };

  const handleClearLogs = () => {
    setConsoleLogs([]);
    setStages((prev) => prev.map((s) => ({ ...s, status: "idle", duration: undefined })));
  };

  return (
    <div id="execution-console-panel" className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs space-y-6">
      {/* Visual Pipeline Stage diagram */}
      <div>
        <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-1.5 mb-3">
          <Activity className="w-4 h-4 text-indigo-600" />
          Pipeline Stage Monitoring
        </h3>
        <p className="text-xs text-slate-500 mb-4">
          Simulate the deployment phases of the Jenkins CI / dbt execution lifecycle based on configured BigQuery tables:
        </p>

        {/* Stages list */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {stages.map((stage, idx) => {
            let statusColor = "bg-slate-50 border-slate-200 text-slate-400";
            let iconText = `${idx + 1}`;

            if (stage.status === "running") {
              statusColor = "bg-indigo-50 border-indigo-300 text-indigo-700 ring-2 ring-indigo-100 animate-pulse";
              iconText = "⚙";
            } else if (stage.status === "success") {
              statusColor = "bg-emerald-50 border-emerald-200 text-emerald-800";
              iconText = "✔";
            } else if (stage.status === "failed") {
              statusColor = "bg-red-50 border-red-200 text-red-800";
              iconText = "❌";
            }

            return (
              <div
                key={stage.id}
                className={`p-3 rounded-lg border text-center relative transition-all duration-300 ${statusColor}`}
              >
                {/* Connecting arrow for desktop */}
                {idx < stages.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 -right-2 transform -translate-y-1/2 text-slate-300 z-10 font-bold text-xs">
                    ➔
                  </div>
                )}
                <div className="w-5 h-5 rounded-full bg-white border border-current text-[10px] font-bold mx-auto mb-2 flex items-center justify-center shadow-xs">
                  {iconText}
                </div>
                <div className="text-[11px] font-semibold truncate" title={stage.name}>
                  {stage.name}
                </div>
                {stage.duration && (
                  <div className="text-[9px] text-slate-500 font-mono mt-0.5">
                    elapsed: {stage.duration}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Control Buttons */}
      <div className="flex flex-wrap gap-2.5 pt-2 border-t border-slate-100">
        <button
          type="button"
          id="btn-run-compile"
          onClick={() => runPipelineAction("compile")}
          disabled={isRunning || mappings.length === 0}
          className={`py-2 px-3.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs ${
            isRunning
              ? "bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200"
              : "bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300"
          }`}
        >
          <Terminal className="w-3.5 h-3.5" />
          <span>Validate Run (dbt compile)</span>
        </button>

        <button
          type="button"
          id="btn-run-test"
          onClick={() => runPipelineAction("test")}
          disabled={isRunning || mappings.length === 0}
          className={`py-2 px-3.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs ${
            isRunning
              ? "bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200"
              : "bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300"
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Verify Constraints (dbt test)</span>
        </button>

        <button
          type="button"
          id="btn-run-publish"
          onClick={() => runPipelineAction("publish")}
          disabled={isRunning || mappings.length === 0}
          className={`py-2 px-4 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs ${
            isRunning
              ? "bg-indigo-300 text-indigo-50 cursor-not-allowed"
              : "bg-indigo-600 hover:bg-indigo-700 text-white"
          }`}
        >
          <PlayCircle className="w-3.5 h-3.5" />
          <span>Publish to BigQuery (Materialize Table)</span>
        </button>

        <button
          type="button"
          id="btn-clear-logs"
          onClick={handleClearLogs}
          className="ml-auto py-2 px-3 text-xs text-slate-500 hover:text-slate-800 font-semibold border border-transparent hover:border-slate-200 rounded-lg transition-all cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5 inline mr-1" />
          Reset Simulation
        </button>
      </div>

      {/* Terminal log output */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-500 font-semibold font-mono">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 bg-indigo-500 rounded-full animate-ping" />
            <span>Interactive Terminal logs:</span>
          </div>
          <span>output console: ASCII</span>
        </div>

        <div className="bg-slate-950 text-slate-200 font-mono text-[11px] p-4 rounded-xl border border-slate-850 h-64 overflow-y-auto shadow-inner flex flex-col justify-between scrollbar-thin scrollbar-thumb-slate-800">
          <div>
            {consoleLogs.length === 0 ? (
              <div className="text-slate-500 text-center py-20 italic">
                No logs recorded. Select one of the pipeline deployment actions above to trigger simulated execution output.
              </div>
            ) : (
              consoleLogs.map((log, index) => {
                let textClass = "text-slate-300";
                if (log.includes("[✔]") || log.includes("SUCCESS") || log.includes("PASS")) {
                  textClass = "text-emerald-400 font-semibold";
                } else if (log.includes("[❌") || log.includes("Error") || log.includes("failed")) {
                  textClass = "text-rose-400 font-bold";
                } else if (log.includes(">>>")) {
                  textClass = "text-indigo-400 font-semibold text-xs border-b border-slate-800 pb-1 mt-4 first:mt-0";
                } else if (log.includes("[-]")) {
                  textClass = "text-slate-400";
                } else if (log.includes("[dbt]")) {
                  textClass = "text-indigo-200/90";
                }

                return (
                  <div key={index} className={`whitespace-pre-wrap ${textClass} leading-5`}>
                    {log}
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
