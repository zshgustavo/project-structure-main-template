import { ColumnDef } from "../types";

export interface TableTemplate {
  id: string;
  name: string;
  tableName: string;
  defaultDomain: string;
  description: string;
  columns: ColumnDef[];
}

export const TABLE_TEMPLATES: TableTemplate[] = [
  {
    id: "savings_accounts",
    name: "Legacy Account Records",
    tableName: "legacy_savings_accounts",
    defaultDomain: "Current Account",
    description: "Unstructured savings and checking account logs containing legacy balances, limits, and status codes.",
    columns: [
      { name: "id", type: "INTEGER", description: "Internal account sequence code" },
      { name: "cust_id", type: "INTEGER", description: "Customer primary identifier" },
      { name: "acct_bal", type: "NUMERIC", description: "Current outstanding account ledger balance" },
      { name: "open_dt", type: "DATE", description: "The date the account was originally opened" },
      { name: "status", type: "STRING", description: "Account state code: ACTIVE, CLSD, SUSP" },
      { name: "credit_limit", type: "NUMERIC", description: "Max overdraft limit approved" },
      { name: "acct_type", type: "STRING", description: "Product catalog group code: SAV, CHK, JNT" }
    ]
  },
  {
    id: "customer_profiles",
    name: "Customer Demographics",
    tableName: "legacy_customer_demographics",
    defaultDomain: "Customer Agreement",
    description: "Core banking customer master information with personal metadata, contact details, and compliance state.",
    columns: [
      { name: "customer_id", type: "STRING", description: "Unique customer identifier alphanumeric" },
      { name: "first_name", type: "STRING", description: "First legal name of customer" },
      { name: "last_name", type: "STRING", description: "Last legal name of customer" },
      { name: "email_addr", type: "STRING", description: "Primary email address" },
      { name: "phone_no", type: "STRING", description: "Telephone number including country code" },
      { name: "addr_line_1", type: "STRING", description: "Home postal address line 1" },
      { name: "onboard_dt", type: "DATE", description: "The date the customer signed their agreement" },
      { name: "kyc_status", type: "STRING", description: "Know Your Customer check status: APPROVED, PENDING, REJECTED" }
    ]
  },
  {
    id: "payment_transactions",
    name: "Payment & Transaction Registry",
    tableName: "legacy_payment_transactions",
    defaultDomain: "Payment Execution",
    description: "High-throughput operational settlement logs for domestic and international wire/credit ledger updates.",
    columns: [
      { name: "tx_id", type: "STRING", description: "Unique hex string of payment transaction" },
      { name: "sender_id", type: "STRING", description: "Originator ledger account code" },
      { name: "receiver_id", type: "STRING", description: "Beneficiary ledger account code" },
      { name: "tx_amount", type: "NUMERIC", description: "Absolute financial amount of transfer" },
      { name: "currency", type: "STRING", description: "ISO 3-letter currency code (e.g. USD, EUR)" },
      { name: "tx_date", type: "TIMESTAMP", description: "Precise millisecond transaction execution time" },
      { name: "status", type: "STRING", description: "Settlement code: SETTLED, DECLINED, HOLD" },
      { name: "channel", type: "STRING", description: "Origination method: MOBILE, WEB, BRANCH, ATM" }
    ]
  }
];
