import { BianMapping, ConnectionConfig } from "../types";

export function generateDbtProjectYml(): string {
  return `# dbt_project.yml
name: 'bian_pipeline'
version: '1.0.0'
config-version: 2

profile: 'bian_pipeline'

model-paths: ["models"]
analysis-paths: ["analyses"]
test-paths: ["tests"]
seed-paths: ["seeds"]
macro-paths: ["macros"]
snapshot-paths: ["snapshots"]

clean-targets:
  - "target"
  - "dbt_packages"

models:
  bian_pipeline:
    # Staging models represent simple casting and renaming
    staging:
      +materialized: view
      +schema: staging
    # Core BIAN models represent standardized tables written to destination
    bian:
      +materialized: table
      +schema: bian
`;
}

export function generateProfilesYml(config: ConnectionConfig): string {
  const isSA = config.credentialsType === "service_account";
  return `# profiles.yml
bian_pipeline:
  target: dev
  outputs:
    dev:
      type: bigquery
      method: ${isSA ? "service-account" : "oauth"}
      project: ${config.gcpProject}
      dataset: ${config.datasetDest}
      threads: 4
      timeout_seconds: 300
      priority: interactive
${isSA ? `      keyfile: ${config.saKeyFile || "/var/jenkins_home/secrets/gcp-sa-key.json"}\n` : ""}
`;
}

export function generateSourcesYml(config: ConnectionConfig, mappings: BianMapping[]): string {
  const columnsYaml = mappings
    .map(
      (m) => `          - name: ${m.source_column}
            description: "Original source column. Type: ${m.source_type}. BIAN Target: ${m.bian_column} (${m.bian_data_element})."`
    )
    .join("\n");

  return `# models/sources.yml
version: 2

sources:
  - name: core_banking
    database: ${config.gcpProject}
    schema: ${config.datasetSource}
    tables:
      - name: ${config.tableName}
        description: "Raw database extraction from core transaction journal or legacy account master ledger."
        columns:
${columnsYaml}
`;
}

export function generateStagingSql(config: ConnectionConfig, mappings: BianMapping[]): string {
  const selectFields = mappings
    .map((m) => {
      // If logic is just the column name, use standard naming, else use specified logic
      const expr = m.transformation_logic.trim() === m.source_column
        ? `\`${m.source_column}\``
        : m.transformation_logic;
      return `        ${expr} as \`${m.bian_column}\``;
    })
    .join(",\n");

  return `-- models/staging/stg_${config.tableName}.sql
with raw_source as (
    select * from {{ source('core_banking', '${config.tableName}') }}
),

renamed_and_cast as (
    select
${selectFields}
    from raw_source
)

select * from renamed_and_cast
`;
}

export function generateBianSql(config: ConnectionConfig, mappings: BianMapping[]): string {
  // Identify the unique Service Domain(s) we are aligning to
  const domains = Array.from(new Set(mappings.map(m => m.bian_service_domain)));
  const domainList = domains.length > 0 ? domains.join(", ") : "Current Account";

  const fieldsList = mappings
    .map((m) => `    \`${m.bian_column}\`  -- ${m.bian_data_element} | BIAN-Standard: ${m.description}`)
    .join(",\n");

  return `-- models/bian/${config.tableName}__bian.sql
{{ config(
    materialized='table',
    description='BIAN Standardized table. Service Domain(s): ${domainList}.'
) }}

with staging_records as (
    select * from {{ ref('stg_${config.tableName}') }}
)

select
${fieldsList}
from staging_records
`;
}

export function generateSchemaYml(config: ConnectionConfig, mappings: BianMapping[]): string {
  const uniqueCols = mappings.filter(m => m.bian_data_element === "Identifier" || m.source_column.toLowerCase().includes("id"));
  const primaryKey = uniqueCols.length > 0 ? uniqueCols[0].bian_column : (mappings[0]?.bian_column || "AccountIdentifier");

  const colDefinitions = mappings.map(m => {
    const isPK = m.bian_column === primaryKey;
    const testBlock = isPK 
      ? `\n            tests:\n              - unique\n              - not_null`
      : ``;
    return `      - name: ${m.bian_column}
        description: "${m.description}. [BIAN Data Element: ${m.bian_data_element}]"${testBlock}`;
  }).join("\n");

  return `# models/schema.yml
version: 2

models:
  - name: stg_${config.tableName}
    description: "Staging model which reads from BigQuery source and casts legacy variables into BIAN-compliant formats."

  - name: ${config.tableName}__bian
    description: "Final canonical BIAN analytical table structured for Service Domain reporting."
    columns:
${colDefinitions}
`;
}

export function generateMigratePy(config: ConnectionConfig, mappings: BianMapping[]): string {
  const isSA = config.credentialsType === "service_account";
  return `"""
migrate.py
Automation wrapper script to validate BigQuery schemas, scaffold local dbt-core files,
execute transformations, and publish BIAN-aligned tables to target GCP datasets.
Designed to be executed locally or from CI pipelines (e.g. Jenkins).
"""

import os
import sys
import json
import argparse
import subprocess
from google.cloud import bigquery
from google.oauth2 import service_account

def get_bq_client(args):
    """Initializes Google Cloud BigQuery client with ADC or Service Account."""
    if "${config.credentialsType}" == "service_account" and os.path.exists(args.keyfile):
        print(f"[-] Authenticating using service account keyfile: {args.keyfile}")
        credentials = service_account.Credentials.from_service_account_file(args.keyfile)
        return bigquery.Client(credentials=credentials, project=args.project)
    else:
        print("[-] Authenticating using Application Default Credentials (ADC)...")
        return bigquery.Client(project=args.project)

def scaffold_dbt_files():
    """Dynamically writes the dbt Core project structure based on current configurations."""
    print("[-] Scaffolding dbt-core directory structure and configurations...")
    os.makedirs("dbt/models/staging", exist_ok=True)
    os.makedirs("dbt/models/bian", exist_ok=True)
    
    # Save dbt_project.yml
    with open("dbt/dbt_project.yml", "w") as f:
        f.write(r"""${generateDbtProjectYml()}""")
        
    # Save profiles.yml
    with open("dbt/profiles.yml", "w") as f:
        f.write(r"""${generateProfilesYml(config)}""")
        
    # Save sources.yml
    with open("dbt/models/sources.yml", "w") as f:
        f.write(r"""${generateSourcesYml(config, mappings)}""")
        
    # Save staging model
    with open("dbt/models/staging/stg_${config.tableName}.sql", "w") as f:
        f.write(r"""${generateStagingSql(config, mappings)}""")
        
    # Save target BIAN model
    with open("dbt/models/bian/${config.tableName}__bian.sql", "w") as f:
        f.write(r"""${generateBianSql(config, mappings)}""")

    # Save schema description and tests
    with open("dbt/models/schema.yml", "w") as f:
        f.write(r"""${generateSchemaYml(config, mappings)}""")

    print("[✔] dbt project configuration successfully scaffolded!")

def check_source_schema(client):
    """Verifies that the source BigQuery table exists and inspects columns."""
    print(f"[-] Validating source schema catalog: {config.gcpProject}.{config.datasetSource}.${config.tableName}")
    table_ref = f"{config.gcpProject}.${config.datasetSource}.${config.tableName}"
    try:
        table = client.get_table(table_ref)
        print(f"[✔] Found source table. Rows count: {table.num_rows}, Columns: {len(table.schema)}")
        for field in table.schema:
            print(f"    ├─ Field: {field.name} ({field.field_type})")
        return True
    except Exception as e:
        print(f"[❌] Error locating or accessing source table {table_ref}: {str(e)}")
        return False

def run_dbt_command(command_list):
    """Executes a local dbt CLI process with standard logging."""
    print(f"[-] Running dbt command: {' '.join(command_list)}")
    env = os.environ.copy()
    # Direct dbt to use the local profiles file inside dbt/ directory
    env["DBT_PROFILES_DIR"] = "./dbt"
    
    process = subprocess.Popen(
        command_list,
        cwd="./dbt",
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        env=env
    )
    
    for line in process.stdout:
        print(f"    [dbt] {line.strip()}")
        
    process.wait()
    return process.returncode == 0

def main():
    parser = argparse.ArgumentParser(description="BigQuery BIAN dbt Pipeline Automation")
    parser.add_argument("--action", choices=["compile", "test", "publish"], required=True, help="Pipeline phase to execute")
    parser.add_argument("--project", default="${config.gcpProject}", help="GCP project ID")
    parser.add_argument("--keyfile", default="${config.saKeyFile || 'secrets/sa-key.json'}", help="Path to GCP service account JSON credentials")
    args = parser.parse_args()

    # Always scaffold dbt project first
    scaffold_dbt_files()
    
    # Initialize GCP bigquery client
    try:
        client = get_bq_client(args)
    except Exception as e:
        print(f"[❌] GCP authentication failure: {str(e)}")
        sys.exit(1)

    # Validate schema availability
    if not check_source_schema(client):
        print("[❌] Schema validation aborted. Pipeline terminating.")
        sys.exit(1)

    # Execute specific phase action
    if args.action == "compile":
        print("[-] Phase 1: Running dbt compile...")
        success = run_dbt_command(["dbt", "compile"])
        if success:
            print("[✔] Pipeline compilation successful. Local target SQL queries validated.")
        else:
            print("[❌] dbt compilation failed.")
            sys.exit(1)
            
    elif args.action == "test":
        print("[-] Phase 2: Running dbt tests...")
        success = run_dbt_command(["dbt", "test"])
        if success:
            print("[✔] Verification completed. All unit & integrity tests passed.")
        else:
            print("[❌] Schema assertions or constraint testing failed.")
            sys.exit(1)
            
    elif args.action == "publish":
        print("[-] Phase 3: Building & Publishing models in target dataset...")
        # dbt run triggers the actual view/table creation on the target BigQuery dataset
        success = run_dbt_command(["dbt", "run"])
        if success:
            print(f"[✔] Standardized BIAN model successfully materialized at {config.gcpProject}.${config.datasetDest}.${config.tableName}__bian")
        else:
            print("[❌] Materialization run failed.")
            sys.exit(1)

if __name__ == "__main__":
    main()
`;
}

export function generateJenkinsfile(config: ConnectionConfig): string {
  return `// Jenkinsfile
pipeline {
    agent any

    options {
        timeout(time: 30, unit: 'MINUTES')
        buildDiscarder(logRotator(numToKeepStr: '15'))
        disableConcurrentBuilds()
    }

    environment {
        // GCP credentials setup
        GCP_PROJECT = "${config.gcpProject}"
        CREDENTIALS_ID = "gcp-service-account-key"
        KEY_FILE_PATH = "secrets/gcp-sa-key.json"
    }

    stages {
        stage('Checkout Source') {
            steps {
                echo "[-] Fetching latest branch commits..."
                checkout scm
            }
        }

        stage('Install System Dependencies') {
            steps {
                echo "[-] Upgrading virtualenv, compiling dbt bigquery components..."
                sh '''
                    python3 -m venv venv
                    . venv/bin/activate
                    pip install --upgrade pip
                    pip install dbt-bigquery google-cloud-bigquery
                '''
            }
        }

        stage('Bind GCP Credentials') {
            steps {
                echo "[-] Injecting Jenkins Credentials Bindings..."
                // Standard Jenkins credential mapping of JSON secrets into file path
                withCredentials([file(credentialsId: "\${CREDENTIALS_ID}", variable: 'SA_KEY_FILE')]) {
                    sh "mkdir -p secrets"
                    sh "cp \\$SA_KEY_FILE \\$KEY_FILE_PATH"
                }
            }
        }

        stage('dbt Compilation & Parse') {
            steps {
                echo "[-] Compiling dbt structures and validating BigQuery catalog access..."
                sh '''
                    . venv/bin/activate
                    python migrate.py --action compile --project \${GCP_PROJECT} --keyfile \${KEY_FILE_PATH}
                '''
            }
        }

        stage('Schema Quality Tests') {
            steps {
                echo "[-] Running target BIAN unique & not-null dbt tests..."
                sh '''
                    . venv/bin/activate
                    python migrate.py --action test --project \${GCP_PROJECT} --keyfile \${KEY_FILE_PATH}
                '''
            }
        }

        stage('CD Deploy (Publish)') {
            when {
                branch 'main'
            }
            steps {
                echo "[-] Releasing BIAN schema to target production dataset: ${config.datasetDest}..."
                sh '''
                    . venv/bin/activate
                    python migrate.py --action publish --project \${GCP_PROJECT} --keyfile \${KEY_FILE_PATH}
                '''
            }
        }
    }

    post {
        always {
            echo "[-] Cleaning up temporary environment files..."
            sh "rm -f secrets/gcp-sa-key.json"
        }
        success {
            echo "[✔] BIAN alignment pipeline succeeded! Target table is up-to-date."
        }
        failure {
            echo "[❌] Pipeline failed. Check dbt logs or BigQuery job details above."
        }
    }
}
`;
}
