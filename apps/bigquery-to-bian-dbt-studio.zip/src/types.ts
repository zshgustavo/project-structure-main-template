export interface ColumnDef {
  name: string;
  type: string;
  description: string;
}

export interface BianMapping {
  source_column: string;
  source_type: string;
  bian_column: string;
  bian_data_element: "Identifier" | "Amount" | "Date" | "Text" | "Status" | "Code";
  transformation_logic: string;
  bian_service_domain: string;
  confidence: "high" | "medium" | "low";
  description: string;
}

export interface ConnectionConfig {
  gcpProject: string;
  datasetSource: string;
  datasetDest: string;
  tableName: string;
  credentialsType: "adc" | "service_account";
  saEmail: string;
  saKeyFile: string;
}

export interface PipelineStage {
  id: string;
  name: string;
  status: "idle" | "running" | "success" | "failed";
  duration?: string;
}
