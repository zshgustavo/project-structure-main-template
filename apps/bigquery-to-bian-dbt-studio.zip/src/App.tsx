import React from "react";
import { ConnectionConfig, ColumnDef, BianMapping } from "./types";
import { TABLE_TEMPLATES, TableTemplate } from "./data/templates";
import ConnectionConfigPanel from "./components/ConnectionConfig";
import MappingBoard from "./components/MappingBoard";
import CodeExporter from "./components/CodeExporter";
import ExecutionConsole from "./components/ExecutionConsole";
import { Layers, Settings, Play, FileCode, Database, Cpu, HelpCircle, CheckCircle2, AlertCircle } from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = React.useState<"design" | "code" | "runner">("design");

  // App states
  const [config, setConfig] = React.useState<ConnectionConfig>({
    gcpProject: "gcp-finance-prod",
    datasetSource: "core_banking_raw",
    datasetDest: "bian_standardized",
    tableName: TABLE_TEMPLATES[0].tableName,
    credentialsType: "adc",
    saEmail: "",
    saKeyFile: "",
  });

  const [columns, setColumns] = React.useState<ColumnDef[]>(TABLE_TEMPLATES[0].columns);
  const [mappings, setMappings] = React.useState<BianMapping[]>([]);
  const [activeTemplateId, setActiveTemplateId] = React.useState<string>(TABLE_TEMPLATES[0].id);
  const [selectedDomain, setSelectedDomain] = React.useState<string>(TABLE_TEMPLATES[0].defaultDomain);
  const [geminiConnected, setGeminiConnected] = React.useState<boolean>(false);

  // Check backend server health and Gemini API capabilities
  React.useEffect(() => {
    fetch("/api/health")
      .then((res) => res.json())
      .then((data) => {
        if (data.geminiEnabled) {
          setGeminiConnected(true);
        }
      })
      .catch((err) => console.log("Backend not fully ready or checking: ", err));
  }, []);

  const handleSelectTemplate = (tmpl: TableTemplate) => {
    setActiveTemplateId(tmpl.id);
    setSelectedDomain(tmpl.defaultDomain);
    setColumns(tmpl.columns);
    setMappings([]); // Clearing triggers automatic heuristic mappings calculation in MappingBoard
    setConfig((prev) => ({
      ...prev,
      tableName: tmpl.tableName,
    }));
  };

  const handleColumnsChange = (newCols: ColumnDef[]) => {
    setColumns(newCols);
    setMappings([]); // Trigger reset
    setActiveTemplateId(""); // Clear active pre-built template badge as schema is customized
  };

  const handleDomainChange = (domain: string) => {
    setSelectedDomain(domain);
    // Adjust mapping target domains dynamically
    if (mappings.length > 0) {
      const updated = mappings.map((m) => ({
        ...m,
        bian_service_domain: domain,
      }));
      setMappings(updated);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col antialiased">
      {/* Dynamic Header */}
      <header className="bg-white border-b border-slate-200 py-3 px-6 shrink-0 shadow-xs">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2.5 rounded-xl text-white shadow-md shadow-indigo-100 flex items-center justify-center">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-base font-bold text-slate-900 leading-tight">
                BigQuery to BIAN dbt Studio
              </h1>
              <p className="text-xs text-slate-500">
                Interactive schema alignment, pipeline dbt scaffolding, and Jenkins CD simulator
              </p>
            </div>
          </div>

          {/* System Capability Badges */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1.5 bg-slate-100 border border-slate-200 rounded-full px-2.5 py-1 text-[11px] font-medium text-slate-600">
              <Database className="w-3.5 h-3.5 text-slate-500" />
              <span>BQ-GCP Client: Active</span>
            </div>

            <div className={`flex items-center gap-1.5 border rounded-full px-2.5 py-1 text-[11px] font-medium transition-colors ${
              geminiConnected
                ? "bg-emerald-50 border-emerald-200 text-emerald-700"
                : "bg-indigo-50 border-indigo-200 text-indigo-700"
            }`}>
              <Cpu className="w-3.5 h-3.5" />
              <span>AI Engine: {geminiConnected ? "Gemini-3.6-Flash" : "Local Heuristics Fallback"}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Stats Summary Strip */}
      <div className="bg-white border-b border-slate-200/60 py-2.5 px-6 shrink-0">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-medium">
          <div className="border-r border-slate-100 pr-4">
            <span className="text-slate-400 block text-[10px] font-bold uppercase tracking-wider">Active GCP Project</span>
            <span className="font-mono text-slate-700 font-semibold">{config.gcpProject}</span>
          </div>
          <div className="border-r border-slate-100 pr-4 pl-0 md:pl-4">
            <span className="text-slate-400 block text-[10px] font-bold uppercase tracking-wider">Source Dataset & Table</span>
            <span className="font-mono text-slate-700 font-semibold truncate block" title={`${config.datasetSource}.${config.tableName}`}>
              {config.datasetSource}.{config.tableName}
            </span>
          </div>
          <div className="border-r border-slate-100 pr-4 pl-0 md:pl-4">
            <span className="text-slate-400 block text-[10px] font-bold uppercase tracking-wider">BIAN Domain Target</span>
            <span className="text-indigo-600 font-semibold">{selectedDomain}</span>
          </div>
          <div className="pl-0 md:pl-4">
            <span className="text-slate-400 block text-[10px] font-bold uppercase tracking-wider">Mapped Columns</span>
            <span className="text-slate-700 font-bold">{mappings.length} columns aligned</span>
          </div>
        </div>
      </div>

      {/* Main Tab Switch Navigation */}
      <div className="bg-white border-b border-slate-200 py-1 shrink-0 px-6">
        <div className="max-w-7xl mx-auto flex gap-1">
          <button
            type="button"
            id="tab-btn-design"
            onClick={() => setActiveTab("design")}
            className={`py-2 px-4 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === "design"
                ? "bg-indigo-50 text-indigo-700 font-bold"
                : "text-slate-500 hover:text-slate-900 hover:bg-slate-50"
            }`}
          >
            <Settings className="w-4 h-4" />
            1. Design & Map Schema
          </button>

          <button
            type="button"
            id="tab-btn-code"
            onClick={() => setActiveTab("code")}
            className={`py-2 px-4 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === "code"
                ? "bg-indigo-50 text-indigo-700 font-bold"
                : "text-slate-500 hover:text-slate-900 hover:bg-slate-50"
            }`}
          >
            <FileCode className="w-4 h-4" />
            2. Scaffolded Code Export
          </button>

          <button
            type="button"
            id="tab-btn-runner"
            onClick={() => setActiveTab("runner")}
            className={`py-2 px-4 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === "runner"
                ? "bg-indigo-50 text-indigo-700 font-bold"
                : "text-slate-500 hover:text-slate-900 hover:bg-slate-50"
            }`}
          >
            <Play className="w-4 h-4" />
            3. Pipeline CD Runner
          </button>
        </div>
      </div>

      {/* Main Workspaces Layout */}
      <main className="flex-1 overflow-y-auto p-6">
        <div className="max-w-7xl mx-auto">
          {activeTab === "design" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Left Column: BigQuery setup + custom columns catalog */}
              <div className="lg:col-span-5 space-y-6">
                <ConnectionConfigPanel
                  config={config}
                  onChangeConfig={setConfig}
                  columns={columns}
                  onChangeColumns={handleColumnsChange}
                  activeTemplateId={activeTemplateId}
                  onSelectTemplate={handleSelectTemplate}
                  selectedDomain={selectedDomain}
                  onChangeDomain={handleDomainChange}
                />
              </div>

              {/* Right Column: Schema mapping board */}
              <div className="lg:col-span-7">
                <MappingBoard
                  columns={columns}
                  mappings={mappings}
                  onChangeMappings={setMappings}
                  tableName={config.tableName}
                  selectedDomain={selectedDomain}
                />
              </div>
            </div>
          )}

          {activeTab === "code" && (
            <div className="space-y-4">
              <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-xl text-xs text-indigo-900 flex items-start gap-2.5">
                <HelpCircle className="w-4.5 h-4.5 text-indigo-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-semibold mb-0.5">Automated Code Generation & Exporter Overview</h4>
                  <p className="text-slate-600">
                    The files displayed below represent the fully generated, production-ready pipeline assets based on your visual dbt mapping configurations. Copy or download these artifacts directly to commit them into your repository and let Jenkins deploy them seamlessly in GCP!
                  </p>
                </div>
              </div>
              <CodeExporter config={config} mappings={mappings} />
            </div>
          )}

          {activeTab === "runner" && (
            <div className="space-y-4">
              <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl text-xs text-emerald-900 flex items-start gap-2.5">
                <CheckCircle2 className="w-4.5 h-4.5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-semibold mb-0.5">High Fidelity CI/CD Simulation Environment</h4>
                  <p className="text-slate-600">
                    Validate compile steps, trigger standard unit schema assertions, and simulate deploying the standardized BIAN materialization outputs directly onto target BigQuery tables before pushing to Jenkins.
                  </p>
                </div>
              </div>
              <ExecutionConsole config={config} mappings={mappings} />
            </div>
          )}
        </div>
      </main>

      {/* Unified footer */}
      <footer className="bg-white border-t border-slate-200 py-3 px-6 text-center text-[11px] text-slate-400 shrink-0">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2">
          <span>BigQuery to BIAN dbt Pipeline Studio © 2026. Aligned to BIAN Semantic Standards and dbt Core.</span>
          <div className="flex gap-4">
            <a href="https://bian.org" target="_blank" rel="noopener noreferrer" className="hover:text-indigo-600 font-medium">BIAN Standards</a>
            <a href="https://docs.getdbt.com" target="_blank" rel="noopener noreferrer" className="hover:text-indigo-600 font-medium">dbt Core Docs</a>
            <a href="https://cloud.google.com/bigquery" target="_blank" rel="noopener noreferrer" className="hover:text-indigo-600 font-medium">GCP BigQuery</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
