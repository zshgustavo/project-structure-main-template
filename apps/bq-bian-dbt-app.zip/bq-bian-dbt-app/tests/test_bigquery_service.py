from pathlib import Path
from types import SimpleNamespace

import pytest

from bq_bian_app.bigquery_service import BigQueryInspector
from bq_bian_app.config import load_config
from bq_bian_app.errors import AuthenticationError


def _write_config(tmp_path: Path) -> Path:
    config_path = tmp_path / "config.yml"
    config_path.write_text(
        """
pipeline_name: demo

auth:
  method: service-account
  credentials_path_env: GOOGLE_APPLICATION_CREDENTIALS

bigquery:
  project_id: my-gcp-project
  location: us-central1
  source:
    dataset: raw_banking
    table: customer_accounts
  target:
    dataset: analytics_bian

dbt:
  project_name: demo_project
  profile_name: demo_profile

field_mappings:
  account_id: servicing_arrangement_reference
""".strip(),
        encoding="utf-8",
    )
    return config_path


def test_create_client_requires_credentials_env_var(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.delenv("GOOGLE_APPLICATION_CREDENTIALS", raising=False)
    config = load_config(_write_config(tmp_path))

    with pytest.raises(AuthenticationError, match="GOOGLE_APPLICATION_CREDENTIALS"):
        BigQueryInspector(config).create_client()


def test_inspect_source_table_returns_schema_metadata(
    tmp_path: Path,
    monkeypatch,
) -> None:
    config_path = tmp_path / "oauth_config.yml"
    config_path.write_text(
        """
pipeline_name: demo

auth:
  method: oauth

bigquery:
  project_id: my-gcp-project
  location: US
  source:
    dataset: raw_banking
    table: customer_accounts
  target:
    dataset: analytics_bian

dbt:
  project_name: demo_project
  profile_name: demo_profile

field_mappings:
  account_id: servicing_arrangement_reference
""".strip(),
        encoding="utf-8",
    )

    fake_table = SimpleNamespace(
        project="my-gcp-project",
        dataset_id="raw_banking",
        table_id="customer_accounts",
        location="US",
        num_rows=10,
        num_bytes=512,
        schema=[
            SimpleNamespace(
                name="account_id",
                field_type="STRING",
                mode="NULLABLE",
                description="Source account identifier.",
            )
        ],
    )

    class FakeClient:
        def get_table(self, full_table_id: str):
            assert full_table_id == "my-gcp-project.raw_banking.customer_accounts"
            return fake_table

    monkeypatch.setattr(
        "bq_bian_app.bigquery_service.bigquery.Client",
        lambda project, location: FakeClient(),
    )

    inspection = BigQueryInspector(load_config(config_path)).inspect_source_table()

    assert inspection.full_table_id == "my-gcp-project.raw_banking.customer_accounts"
    assert inspection.row_count == 10
    assert inspection.size_bytes == 512
    assert inspection.columns[0].name == "account_id"
    assert inspection.columns[0].field_type == "STRING"
