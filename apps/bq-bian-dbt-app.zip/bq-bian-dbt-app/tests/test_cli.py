from pathlib import Path

from bq_bian_app.cli import main


def _write_config(tmp_path: Path) -> Path:
    config_path = tmp_path / "config.yml"
    config_path.write_text(
        """
pipeline_name: customer_accounts_bian

auth:
  method: oauth

bigquery:
  project_id: my-gcp-project
  location: us-central1
  source:
    dataset: raw_banking
    table: customer_accounts
  target:
    dataset: analytics_bian
    include_unmapped_columns: true

dbt:
  project_name: customer_accounts_bian
  profile_name: customer_accounts_bian
  source_name: raw_customer_accounts
  staging_model_name: stg_customer_accounts
  bian_model_name: bian_customer_accounts
  threads: 4
  staging_materialized: view
  output_materialized: table

field_mappings:
  account_id:
    target_name: servicing_arrangement_reference
    description: BIAN arrangement reference.
  customer_id:
    target_name: party_reference
    description: BIAN party reference.
""".strip(),
        encoding="utf-8",
    )
    return config_path


def test_compile_command_runs_dbt_compile_only(
    tmp_path: Path,
    monkeypatch,
) -> None:
    config_path = _write_config(tmp_path)
    commands: list[tuple[str, list[str]]] = []

    monkeypatch.setattr(
        "bq_bian_app.cli.run_dbt_command",
        lambda project_dir, subcommand, extra_args=None: commands.append(
            (subcommand, list(extra_args or []))
        ),
    )

    exit_code = main(
        [
            "compile",
            "--config",
            str(config_path),
            "--dbt-dir",
            str(tmp_path / "dbt"),
        ]
    )

    assert exit_code == 0
    assert commands == [("compile", [])]


def test_test_command_runs_dbt_test_only(tmp_path: Path, monkeypatch) -> None:
    config_path = _write_config(tmp_path)
    commands: list[tuple[str, list[str]]] = []

    monkeypatch.setattr(
        "bq_bian_app.cli.run_dbt_command",
        lambda project_dir, subcommand, extra_args=None: commands.append(
            (subcommand, list(extra_args or []))
        ),
    )

    exit_code = main(
        [
            "test",
            "--config",
            str(config_path),
            "--dbt-dir",
            str(tmp_path / "dbt"),
        ]
    )

    assert exit_code == 0
    assert commands == [("test", [])]


def test_publish_requires_confirmation(tmp_path: Path) -> None:
    config_path = _write_config(tmp_path)

    exit_code = main(
        [
            "publish",
            "--config",
            str(config_path),
            "--dbt-dir",
            str(tmp_path / "dbt"),
        ]
    )

    assert exit_code == 1


def test_publish_forwards_dbt_run_arguments(tmp_path: Path, monkeypatch) -> None:
    config_path = _write_config(tmp_path)
    commands: list[tuple[str, list[str]]] = []

    monkeypatch.setattr(
        "bq_bian_app.cli.run_dbt_command",
        lambda project_dir, subcommand, extra_args=None: commands.append(
            (subcommand, list(extra_args or []))
        ),
    )

    exit_code = main(
        [
            "publish",
            "--config",
            str(config_path),
            "--dbt-dir",
            str(tmp_path / "dbt"),
            "--confirm-publish",
            "--full-refresh",
            "--select",
            "bian_customer_accounts",
        ]
    )

    assert exit_code == 0
    assert commands == [
        ("run", ["--full-refresh", "--select", "bian_customer_accounts"])
    ]
