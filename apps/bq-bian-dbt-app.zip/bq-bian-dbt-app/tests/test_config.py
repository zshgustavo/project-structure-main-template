from pathlib import Path

import pytest

from bq_bian_app.config import load_config
from bq_bian_app.errors import ConfigError


def _write_config(tmp_path: Path, content: str) -> Path:
    config_path = tmp_path / "config.yml"
    config_path.write_text(content, encoding="utf-8")
    return config_path


def test_load_config_derives_dbt_defaults_and_expands_environment_values(
    tmp_path: Path,
    monkeypatch,
) -> None:
    monkeypatch.setenv("GCP_PROJECT", "my-gcp-project")
    config = load_config(
        _write_config(
            tmp_path,
            """
pipeline_name: Customer Accounts Pipeline

auth:
  method: service-account
  credentials_path_env: GOOGLE_APPLICATION_CREDENTIALS

bigquery:
  project_id: ${GCP_PROJECT}
  location: us-central1
  source:
    dataset: raw_banking
    table: customer_accounts
  target:
    dataset: analytics_bian
    include_unmapped_columns: true

dbt:
  threads: 8

field_mappings:
  account_id:
    target_name: servicing_arrangement_reference
    tests:
      - not_null
  customer_id: party_reference
""".strip(),
        )
    )

    assert config.bigquery.project_id == "my-gcp-project"
    assert config.dbt.project_name == "customer_accounts_pipeline"
    assert config.dbt.profile_name == "customer_accounts_pipeline"
    assert config.dbt.source_name == "src_customer_accounts"
    assert config.dbt.staging_model_name == "stg_customer_accounts"
    assert config.dbt.bian_model_name == "bian_customer_accounts"
    assert config.dbt.threads == 8
    assert config.bigquery.target.include_unmapped_columns is True
    assert config.field_mappings["account_id"].tests == ("not_null",)


def test_load_config_rejects_duplicate_bian_targets(tmp_path: Path) -> None:
    config_path = _write_config(
        tmp_path,
        """
pipeline_name: demo

auth:
  method: oauth

bigquery:
  project_id: my-gcp-project
  location: US
  source:
    dataset: raw_banking
    table: customer_accounts
  target:
    dataset: analytics_bian

dbt:
  project_name: demo_project
  profile_name: demo_profile

field_mappings:
  account_id: shared_target
  customer_id: shared_target
""".strip(),
    )

    with pytest.raises(ConfigError, match="Duplicate BIAN target name"):
        load_config(config_path)


def test_load_config_requires_service_account_env_name(tmp_path: Path) -> None:
    config_path = _write_config(
        tmp_path,
        """
pipeline_name: demo

auth:
  method: service-account

bigquery:
  project_id: my-gcp-project
  location: US
  source:
    dataset: raw_banking
    table: customer_accounts
  target:
    dataset: analytics_bian

dbt:
  project_name: demo_project
  profile_name: demo_profile

field_mappings:
  account_id: servicing_arrangement_reference
""".strip(),
    )

    with pytest.raises(ConfigError, match="auth.credentials_path_env"):
        load_config(config_path)


def test_load_config_requires_different_target_dataset(tmp_path: Path) -> None:
    config_path = _write_config(
        tmp_path,
        """
pipeline_name: demo

auth:
  method: oauth

bigquery:
  project_id: my-gcp-project
  location: us-central1
  source:
    dataset: raw_banking
    table: customer_accounts
  target:
    dataset: raw_banking

dbt:
  project_name: demo_project
  profile_name: demo_profile

field_mappings:
  account_id: servicing_arrangement_reference
""".strip(),
    )

    with pytest.raises(ConfigError, match="must be different"):
        load_config(config_path)
