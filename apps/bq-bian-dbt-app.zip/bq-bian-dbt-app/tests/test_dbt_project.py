from pathlib import Path

import yaml

from bq_bian_app.bigquery_service import SourceColumn, TableInspection
from bq_bian_app.config import load_config
from bq_bian_app.dbt_project import generate_dbt_project


def _write_config(tmp_path: Path) -> Path:
    config_path = tmp_path / "config.yml"
    config_path.write_text(
        """
pipeline_name: customer_accounts_bian

auth:
  method: service-account
  credentials_path_env: GOOGLE_APPLICATION_CREDENTIALS

bigquery:
  project_id: my-gcp-project
  location: us-central1
  source:
    dataset: raw_banking
    table: customer_accounts
  target:
    dataset: analytics_bian
    include_unmapped_columns: true

dbt:
  project_name: customer_accounts_bian
  profile_name: customer_accounts_bian
  source_name: raw_customer_accounts
  staging_model_name: stg_customer_accounts
  bian_model_name: bian_customer_accounts
  threads: 4
  staging_materialized: view
  output_materialized: table

field_mappings:
  account_id:
    target_name: servicing_arrangement_reference
    description: BIAN arrangement reference.
    tests:
      - not_null
      - unique
  customer_id:
    target_name: party_reference
    description: BIAN party reference.
  account_status:
    target_name: servicing_arrangement_status
    description: BIAN arrangement status.
""".strip(),
        encoding="utf-8",
    )
    return config_path


def _build_inspection() -> TableInspection:
    return TableInspection(
        project_id="my-gcp-project",
        dataset_id="raw_banking",
        table_id="customer_accounts",
        location="us-central1",
        row_count=125,
        size_bytes=2048,
        columns=(
            SourceColumn(
                name="account_id",
                field_type="STRING",
                mode="NULLABLE",
                description="Source account identifier.",
            ),
            SourceColumn(
                name="customer_id",
                field_type="STRING",
                mode="NULLABLE",
                description="Source customer identifier.",
            ),
            SourceColumn(
                name="account_status",
                field_type="STRING",
                mode="NULLABLE",
                description=None,
            ),
            SourceColumn(
                name="last_updated_at",
                field_type="TIMESTAMP",
                mode="REQUIRED",
                description="Last source update timestamp.",
            ),
        ),
    )


def test_generate_dbt_project_writes_expected_artifacts(tmp_path: Path) -> None:
    config = load_config(_write_config(tmp_path))
    inspection = _build_inspection()
    dbt_dir = tmp_path / "dbt"

    generated_files = generate_dbt_project(config, inspection, dbt_dir)

    assert len(generated_files) == 6

    profiles = yaml.safe_load((dbt_dir / "profiles.yml").read_text(encoding="utf-8"))
    sources = yaml.safe_load((dbt_dir / "models" / "sources.yml").read_text(encoding="utf-8"))
    schema = yaml.safe_load((dbt_dir / "models" / "schema.yml").read_text(encoding="utf-8"))
    staging_sql = (dbt_dir / "models" / "staging" / "stg_customer_accounts.sql").read_text(
        encoding="utf-8"
    )
    bian_sql = (dbt_dir / "models" / "bian" / "bian_customer_accounts.sql").read_text(
        encoding="utf-8"
    )

    assert profiles["customer_accounts_bian"]["outputs"]["default"]["dataset"] == "analytics_bian"
    assert profiles["customer_accounts_bian"]["outputs"]["default"]["project"] == "my-gcp-project"
    assert (
        profiles["customer_accounts_bian"]["outputs"]["default"]["keyfile"]
        == "{{ env_var('GOOGLE_APPLICATION_CREDENTIALS') }}"
    )

    source_definition = sources["sources"][0]
    assert source_definition["database"] == "my-gcp-project"
    assert source_definition["schema"] == "raw_banking"
    assert source_definition["tables"][0]["name"] == "customer_accounts"

    assert "from {{ source('raw_customer_accounts', 'customer_accounts') }}" in staging_sql
    assert "`account_id` as `servicing_arrangement_reference`" in bian_sql
    assert "`customer_id` as `party_reference`" in bian_sql
    assert "`last_updated_at` as `last_updated_at`" in bian_sql

    bian_columns = schema["models"][1]["columns"]
    assert bian_columns[0]["name"] == "servicing_arrangement_reference"
    assert bian_columns[0]["tests"] == ["not_null", "unique"]
    assert "Derived from source column account_id" in bian_columns[0]["description"]
    assert bian_columns[-1]["name"] == "last_updated_at"
    assert bian_columns[-1]["tests"] == ["not_null"]
