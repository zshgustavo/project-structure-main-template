# bq-bian-dbt-app

Backend-only Python tooling that inspects a BigQuery source table and generates a dedicated dbt Core project under `dbt/` for BIAN-aligned field-name standardization.

## What it does

1. Authenticates to Google Cloud with ADC or a service-account path from an environment variable.
2. Resolves the configured BigQuery source project, dataset, and table.
3. Reads the table schema plus size metadata.
4. Generates a dbt Core project under `dbt/`.
5. Builds a staging model that projects the source table as-is.
6. Builds a BIAN alias model that renames configured source columns only.
7. Preserves unmapped source columns by default so the output stays shape-compatible.
8. Separates safe validation (`dbt compile`, `dbt test`) from publish (`dbt run`).

## Repository layout

```text
main.py
config.example.yml
src/bq_bian_app/
tests/
dbt/                  # generated at runtime
```

## Configuration

Copy `config.example.yml` to a working file such as `config.yml` and update:

- `bigquery.project_id`, `source.dataset`, `source.table`, and `target.dataset`
- `field_mappings` for the source columns that need BIAN-aligned names
- `bigquery.target.include_unmapped_columns` if you want passthrough columns preserved
- `auth.method` and `auth.credentials_path_env` to match your runtime

Runtime settings stay in YAML. Secrets stay in environment variables or Jenkins-managed credentials.

## Authentication

### Service-account file via environment variable

```powershell
$env:GOOGLE_APPLICATION_CREDENTIALS = "C:\secure\svc-account.json"
```

### Local ADC / gcloud auth

Set `auth.method: oauth` in the YAML config and ensure the environment already has working ADC or `gcloud auth application-default login`.

## Local setup

Windows:

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Linux/macOS/Jenkins shell:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
```

## CLI commands

### Inspect the source table

```bash
python main.py inspect --config config.yml
```

Prints the resolved BigQuery table metadata, including row count, table size, and the top-level schema.

### Generate dbt artifacts

```bash
python main.py generate --config config.yml
```

Creates or updates:

- `dbt/dbt_project.yml`
- `dbt/profiles.yml`
- `dbt/models/sources.yml`
- `dbt/models/staging/*.sql`
- `dbt/models/bian/*.sql`
- `dbt/models/schema.yml`

### Validate safely with separate commands

```bash
python main.py compile --config config.yml
python main.py test --config config.yml
```

These commands use the already-generated `dbt/` project and do not publish data.

### Publish intentionally

```bash
python main.py publish --config config.yml --confirm-publish
```

`publish` requires `--confirm-publish` so Jenkins or local operators opt into `dbt run` explicitly. By default it publishes only the generated BIAN model and its dependencies.

## Jenkins-friendly flow

Recommended pipeline stages:

1. Install dependencies into a local `.venv`
2. `python main.py inspect --config config.yml`
3. `python main.py generate --config config.yml`
4. `python main.py compile --config config.yml`
5. `python main.py test --config config.yml`
6. `python main.py publish --config config.yml --confirm-publish`

The first five stages are safe for pre-publish validation. Only the last stage executes the dbt models against BigQuery.

## Notes

- The target dataset is always in the same GCP project as the source table.
- BIAN scope is limited to output field-name standardization; the generated SQL does not perform a canonical business-model reshape.
- Unmapped source columns are preserved by default unless `include_unmapped_columns` is set to `false`.
