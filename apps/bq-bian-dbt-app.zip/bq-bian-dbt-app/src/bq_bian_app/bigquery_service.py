from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path

from google.api_core.exceptions import Forbidden, GoogleAPICallError, NotFound
from google.auth.exceptions import DefaultCredentialsError
from google.cloud import bigquery
from google.oauth2 import service_account

from .config import PipelineConfig
from .errors import AuthenticationError, BigQueryInspectionError


@dataclass(frozen=True)
class SourceColumn:
    name: str
    field_type: str
    mode: str
    description: str | None

    @classmethod
    def from_schema_field(cls, field: bigquery.SchemaField) -> "SourceColumn":
        return cls(
            name=field.name,
            field_type=field.field_type,
            mode=field.mode,
            description=field.description,
        )


@dataclass(frozen=True)
class TableInspection:
    project_id: str
    dataset_id: str
    table_id: str
    location: str | None
    row_count: int
    size_bytes: int
    columns: tuple[SourceColumn, ...]

    @property
    def full_table_id(self) -> str:
        return f"{self.project_id}.{self.dataset_id}.{self.table_id}"


class BigQueryInspector:
    def __init__(self, config: PipelineConfig) -> None:
        self._config = config

    def create_client(self) -> bigquery.Client:
        if self._config.auth.method == "service-account":
            env_name = self._config.auth.credentials_path_env
            if not env_name:
                raise AuthenticationError(
                    "auth.credentials_path_env is required for service-account auth."
                )

            credentials_path = os.environ.get(env_name)
            if not credentials_path:
                raise AuthenticationError(
                    f"Required credential environment variable is not set: {env_name}"
                )

            credential_file = Path(credentials_path)
            if not credential_file.is_file():
                raise AuthenticationError(
                    f"Credential file from {env_name} was not found: {credential_file}"
                )

            try:
                credentials = service_account.Credentials.from_service_account_file(
                    str(credential_file)
                )
            except (OSError, ValueError) as error:
                raise AuthenticationError(
                    f"Unable to load the service-account file from {env_name}: {credential_file}"
                ) from error

            return bigquery.Client(
                project=self._config.bigquery.project_id,
                location=self._config.bigquery.location,
                credentials=credentials,
            )

        try:
            return bigquery.Client(
                project=self._config.bigquery.project_id,
                location=self._config.bigquery.location,
            )
        except DefaultCredentialsError as error:
            raise AuthenticationError(
                "Unable to initialize Google Cloud credentials. "
                "Set GOOGLE_APPLICATION_CREDENTIALS or configure ADC first."
            ) from error

    def inspect_source_table(self) -> TableInspection:
        client = self.create_client()
        full_table_id = (
            f"{self._config.bigquery.project_id}."
            f"{self._config.bigquery.source.dataset}."
            f"{self._config.bigquery.source.table}"
        )

        try:
            table = client.get_table(full_table_id)
        except NotFound as error:
            raise BigQueryInspectionError(
                f"Source BigQuery table was not found: {full_table_id}"
            ) from error
        except Forbidden as error:
            raise AuthenticationError(
                f"Authenticated principal cannot access source table: {full_table_id}"
            ) from error
        except GoogleAPICallError as error:
            raise BigQueryInspectionError(
                f"Unable to inspect source table {full_table_id}: {error}"
            ) from error

        columns = tuple(SourceColumn.from_schema_field(field) for field in table.schema)
        if not columns:
            raise BigQueryInspectionError(
                f"Source BigQuery table has no columns: {full_table_id}"
            )

        return TableInspection(
            project_id=table.project,
            dataset_id=table.dataset_id,
            table_id=table.table_id,
            location=table.location,
            row_count=table.num_rows or 0,
            size_bytes=table.num_bytes or 0,
            columns=columns,
        )
