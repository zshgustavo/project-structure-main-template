from __future__ import annotations

import argparse
from collections.abc import Sequence
import json
import logging
from pathlib import Path

from .bigquery_service import BigQueryInspector, TableInspection
from .config import PipelineConfig, load_config
from .dbt_project import generate_dbt_config_files, generate_dbt_project
from .dbt_runner import run_dbt_command
from .errors import BqBianAppError, ConfigError
from .logging_utils import configure_logging


LOGGER = logging.getLogger(__name__)


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)
    configure_logging(args.log_level)

    try:
        return args.handler(args)
    except BqBianAppError as error:
        LOGGER.error("%s", error)
        return 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Inspect a BigQuery source table and generate a dbt Core project "
            "for BIAN-aligned field-name standardization."
        )
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging verbosity.",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    inspect_parser = subparsers.add_parser(
        "inspect",
        help="Inspect the source table and print JSON metadata.",
    )
    _add_common_arguments(inspect_parser)
    inspect_parser.set_defaults(handler=_handle_inspect)

    generate_parser = subparsers.add_parser(
        "generate",
        help="Inspect the source table and generate dbt artifacts under dbt/.",
    )
    _add_common_arguments(generate_parser)
    generate_parser.add_argument(
        "--skip-inspection",
        action="store_true",
        help=(
            "Skip the BigQuery source-table inspection and only write the "
            "config-derived dbt_project.yml and profiles.yml (useful while the "
            "source table is not reachable yet)."
        ),
    )
    generate_parser.set_defaults(handler=_handle_generate)

    compile_parser = subparsers.add_parser(
        "compile",
        help="Run dbt compile against the existing generated dbt project.",
    )
    _add_common_arguments(compile_parser)
    compile_parser.set_defaults(handler=_handle_compile)

    test_parser = subparsers.add_parser(
        "test",
        help="Run dbt test against the existing generated dbt project.",
    )
    _add_common_arguments(test_parser)
    test_parser.set_defaults(handler=_handle_test)

    publish_parser = subparsers.add_parser(
        "publish",
        help="Run dbt publish intentionally against the existing generated dbt project.",
    )
    _add_common_arguments(publish_parser)
    publish_parser.add_argument(
        "--confirm-publish",
        action="store_true",
        help="Required safety flag before executing dbt run.",
    )
    publish_parser.add_argument(
        "--full-refresh",
        action="store_true",
        help="Pass --full-refresh through to dbt run.",
    )
    publish_parser.add_argument(
        "--select",
        help="Optional dbt selection string forwarded to dbt run.",
    )
    publish_parser.set_defaults(handler=_handle_publish)

    return parser


def _add_common_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--config",
        required=True,
        help="Path to the runtime YAML configuration file.",
    )
    parser.add_argument(
        "--dbt-dir",
        default="dbt",
        help="Directory where the generated dbt project should live.",
    )


def _handle_inspect(args: argparse.Namespace) -> int:
    config = load_config(Path(args.config))
    inspection = _inspect_source_table(config)
    print(
        json.dumps(
            {
                "project_id": inspection.project_id,
                "dataset_id": inspection.dataset_id,
                "table_id": inspection.table_id,
                "location": inspection.location,
                "row_count": inspection.row_count,
                "size_bytes": inspection.size_bytes,
                "full_table_id": inspection.full_table_id,
                "columns": [
                    {
                        "name": column.name,
                        "field_type": column.field_type,
                        "mode": column.mode,
                        "description": column.description,
                    }
                    for column in inspection.columns
                ],
            },
            indent=2,
        )
    )
    return 0


def _handle_generate(args: argparse.Namespace) -> int:
    config = load_config(Path(args.config))

    if args.skip_inspection:
        generated_files = generate_dbt_config_files(config, Path(args.dbt_dir))
        LOGGER.warning(
            "Skipped BigQuery inspection. Generated %s config-only dbt artifact "
            "file(s) under %s. sources.yml, schema.yml, and the staging/BIAN "
            "models were NOT generated; re-run without --skip-inspection once "
            "the source table is reachable.",
            len(generated_files),
            Path(args.dbt_dir).resolve(),
        )
        return 0

    inspection = _inspect_source_table(config)
    generated_files = generate_dbt_project(config, inspection, Path(args.dbt_dir))
    LOGGER.info(
        "Generated %s dbt artifact files under %s.",
        len(generated_files),
        Path(args.dbt_dir).resolve(),
    )
    return 0


def _handle_compile(args: argparse.Namespace) -> int:
    load_config(Path(args.config))
    dbt_dir = Path(args.dbt_dir)
    LOGGER.info("Running dbt compile.")
    run_dbt_command(dbt_dir, "compile")
    return 0


def _handle_test(args: argparse.Namespace) -> int:
    load_config(Path(args.config))
    dbt_dir = Path(args.dbt_dir)
    LOGGER.info("Running dbt test.")
    run_dbt_command(dbt_dir, "test")
    return 0


def _handle_publish(args: argparse.Namespace) -> int:
    if not args.confirm_publish:
        raise ConfigError(
            "Publish is intentionally gated. Re-run with --confirm-publish to execute dbt run."
        )

    config = load_config(Path(args.config))
    dbt_dir = Path(args.dbt_dir)

    extra_args: list[str] = []
    if args.full_refresh:
        extra_args.append("--full-refresh")
    selection = args.select or config.dbt.bian_model_name
    extra_args.extend(["--select", selection])

    LOGGER.info("Running dbt run.")
    run_dbt_command(dbt_dir, "run", extra_args)
    return 0


def _inspect_source_table(config: PipelineConfig) -> TableInspection:
    inspection = BigQueryInspector(config).inspect_source_table()
    LOGGER.info(
        "Resolved source table %s with %s columns, %s rows, and %s bytes.",
        inspection.full_table_id,
        len(inspection.columns),
        inspection.row_count,
        inspection.size_bytes,
    )
    return inspection
