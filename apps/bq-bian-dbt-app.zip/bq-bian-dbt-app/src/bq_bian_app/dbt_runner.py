from __future__ import annotations

from pathlib import Path
import os
import shutil
import subprocess
import sys
from typing import Sequence

from .errors import DbtCommandError, DbtGenerationError


def resolve_dbt_executable(project_dir: Path) -> str:
    local_candidate = Path(sys.executable).resolve().parent / (
        "dbt.exe" if os.name == "nt" else "dbt"
    )
    if local_candidate.is_file():
        return str(local_candidate)

    project_venv_candidate = (
        project_dir.parent / ".venv" / "Scripts" / "dbt.exe"
        if os.name == "nt"
        else project_dir.parent / ".venv" / "bin" / "dbt"
    )
    if project_venv_candidate.is_file():
        return str(project_venv_candidate)

    path_candidate = shutil.which("dbt")
    if path_candidate:
        return path_candidate

    raise DbtGenerationError(
        "dbt executable was not found. Install requirements into the local .venv first."
    )


def run_dbt_command(
    project_dir: Path,
    subcommand: str,
    extra_args: Sequence[str] | None = None,
) -> None:
    project_file = project_dir / "dbt_project.yml"
    profiles_file = project_dir / "profiles.yml"

    if not project_file.is_file():
        raise DbtGenerationError(f"Missing dbt project file: {project_file}")
    if not profiles_file.is_file():
        raise DbtGenerationError(f"Missing dbt profiles file: {profiles_file}")

    command = [
        resolve_dbt_executable(project_dir),
        subcommand,
        "--project-dir",
        str(project_dir),
        "--profiles-dir",
        str(project_dir),
    ]
    if extra_args:
        command.extend(extra_args)

    environment = os.environ.copy()
    environment["DBT_PROFILES_DIR"] = str(project_dir)

    completed = subprocess.run(
        command,
        cwd=project_dir,
        env=environment,
        check=False,
    )
    if completed.returncode != 0:
        raise DbtCommandError(command, completed.returncode)
