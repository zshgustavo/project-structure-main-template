class BqBianAppError(Exception):
    """Base exception for the application."""


class ConfigError(BqBianAppError):
    """Raised when the YAML configuration is invalid."""


class AuthenticationError(BqBianAppError):
    """Raised when GCP authentication settings are invalid or unavailable."""


class BigQueryInspectionError(BqBianAppError):
    """Raised when the source BigQuery table cannot be inspected."""


class DbtGenerationError(BqBianAppError):
    """Raised when dbt project generation fails."""


class DbtCommandError(BqBianAppError):
    """Raised when a dbt CLI command exits with an error."""

    def __init__(self, command: list[str], exit_code: int) -> None:
        self.command = command
        self.exit_code = exit_code
        super().__init__(
            f"dbt command failed with exit code {exit_code}: {' '.join(command)}"
        )

