from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import re
from typing import Any

import yaml

from .errors import ConfigError


IDENTIFIER_PATTERN = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
ENV_VAR_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}")
VALID_AUTH_METHODS = {"oauth", "service-account"}
VALID_MATERIALIZATIONS = {"ephemeral", "incremental", "table", "view"}
TestSpec = str | dict[str, Any]


@dataclass(frozen=True)
class AuthConfig:
    method: str
    credentials_path_env: str | None


@dataclass(frozen=True)
class BigQuerySourceConfig:
    dataset: str
    table: str


@dataclass(frozen=True)
class BigQueryTargetConfig:
    dataset: str
    include_unmapped_columns: bool = True


@dataclass(frozen=True)
class BigQueryConfig:
    project_id: str
    location: str
    source: BigQuerySourceConfig
    target: BigQueryTargetConfig


@dataclass(frozen=True)
class FieldMapping:
    source_name: str
    target_name: str
    description: str
    tests: tuple[TestSpec, ...]


@dataclass(frozen=True)
class DbtConfig:
    project_name: str
    profile_name: str
    source_name: str
    staging_model_name: str
    bian_model_name: str
    threads: int
    staging_materialized: str
    output_materialized: str


@dataclass(frozen=True)
class PipelineConfig:
    pipeline_name: str
    auth: AuthConfig
    bigquery: BigQueryConfig
    dbt: DbtConfig
    field_mappings: dict[str, FieldMapping]


def load_config(path: Path) -> PipelineConfig:
    if not path.is_file():
        raise ConfigError(f"Config file not found: {path}")

    try:
        raw_text = path.read_text(encoding="utf-8")
    except OSError as error:
        raise ConfigError(f"Unable to read config file {path}: {error}") from error

    try:
        raw_config = yaml.safe_load(raw_text)
    except yaml.YAMLError as error:
        raise ConfigError(f"Invalid YAML in config file {path}: {error}") from error

    raw_config = _expand_environment_values(raw_config)

    if not isinstance(raw_config, dict):
        raise ConfigError("Config root must be a YAML object.")

    return _parse_pipeline_config(raw_config)


def _parse_pipeline_config(raw_config: dict[str, Any]) -> PipelineConfig:
    pipeline_name = _require_string(raw_config.get("pipeline_name"), "pipeline_name")

    auth_section = _require_dict(raw_config.get("auth"), "auth")
    bigquery_section = _require_dict(raw_config.get("bigquery"), "bigquery")
    dbt_section = _require_dict(raw_config.get("dbt"), "dbt")
    field_mappings_section = _require_dict(
        raw_config.get("field_mappings"),
        "field_mappings",
    )

    bigquery_source_section = _require_dict(bigquery_section.get("source"), "bigquery.source")
    bigquery_target_section = _require_dict(bigquery_section.get("target"), "bigquery.target")

    auth_method = _require_string(auth_section.get("method"), "auth.method")
    if auth_method not in VALID_AUTH_METHODS:
        raise ConfigError(
            "auth.method must be one of: " + ", ".join(sorted(VALID_AUTH_METHODS))
        )

    credentials_path_env = auth_section.get("credentials_path_env")
    if auth_method == "service-account":
        credentials_path_env = _require_identifier(
            credentials_path_env,
            "auth.credentials_path_env",
        )
    elif credentials_path_env is not None:
        credentials_path_env = _require_identifier(
            credentials_path_env,
            "auth.credentials_path_env",
        )

    project_id = _require_string(bigquery_section.get("project_id"), "bigquery.project_id")
    location = _require_string(bigquery_section.get("location"), "bigquery.location")
    source_dataset = _require_string(
        bigquery_source_section.get("dataset"),
        "bigquery.source.dataset",
    )
    source_table = _require_string(
        bigquery_source_section.get("table"),
        "bigquery.source.table",
    )
    target_dataset = _require_string(
        bigquery_target_section.get("dataset"),
        "bigquery.target.dataset",
    )
    include_unmapped_columns = _require_bool(
        bigquery_target_section.get("include_unmapped_columns", True),
        "bigquery.target.include_unmapped_columns",
    )
    if target_dataset == source_dataset:
        raise ConfigError(
            "bigquery.target.dataset must be different from bigquery.source.dataset."
        )

    table_identifier = _derive_identifier(source_table, "bigquery.source.table")
    default_project_name = _derive_identifier(pipeline_name, "dbt.project_name")

    project_name = dbt_section.get("project_name")
    if project_name is None:
        project_name = default_project_name
    else:
        project_name = _require_identifier(project_name, "dbt.project_name")

    profile_name = dbt_section.get("profile_name")
    if profile_name is None:
        profile_name = project_name
    else:
        profile_name = _require_identifier(profile_name, "dbt.profile_name")

    source_name = dbt_section.get("source_name")
    if source_name is None:
        source_name = f"src_{table_identifier}"
    else:
        source_name = _require_identifier(source_name, "dbt.source_name")

    staging_model_name = dbt_section.get("staging_model_name")
    if staging_model_name is None:
        staging_model_name = f"stg_{table_identifier}"
    else:
        staging_model_name = _require_identifier(
            staging_model_name,
            "dbt.staging_model_name",
        )

    bian_model_name = dbt_section.get("bian_model_name")
    if bian_model_name is None:
        bian_model_name = f"bian_{table_identifier}"
    else:
        bian_model_name = _require_identifier(
            bian_model_name,
            "dbt.bian_model_name",
        )

    threads = _require_positive_int(dbt_section.get("threads", 4), "dbt.threads")
    staging_materialized = _require_materialization(
        dbt_section.get("staging_materialized", "view"),
        "dbt.staging_materialized",
    )
    output_materialized = _require_materialization(
        dbt_section.get("output_materialized", "table"),
        "dbt.output_materialized",
    )

    field_mappings = _parse_field_mappings(field_mappings_section)

    return PipelineConfig(
        pipeline_name=pipeline_name,
        auth=AuthConfig(
            method=auth_method,
            credentials_path_env=credentials_path_env,
        ),
        bigquery=BigQueryConfig(
            project_id=project_id,
            location=location,
            source=BigQuerySourceConfig(
                dataset=source_dataset,
                table=source_table,
            ),
            target=BigQueryTargetConfig(
                dataset=target_dataset,
                include_unmapped_columns=include_unmapped_columns,
            ),
        ),
        dbt=DbtConfig(
            project_name=project_name,
            profile_name=profile_name,
            source_name=source_name,
            staging_model_name=staging_model_name,
            bian_model_name=bian_model_name,
            threads=threads,
            staging_materialized=staging_materialized,
            output_materialized=output_materialized,
        ),
        field_mappings=field_mappings,
    )


def _expand_environment_values(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _expand_environment_values(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_expand_environment_values(item) for item in value]
    if not isinstance(value, str):
        return value

    def replace(match: re.Match[str]) -> str:
        env_name = match.group(1)
        default_value = match.group(2)
        env_value = os.getenv(env_name)
        if env_value not in (None, ""):
            return env_value
        if default_value is not None:
            return default_value
        raise ConfigError(f"Environment variable '{env_name}' is required by the YAML config.")

    return ENV_VAR_PATTERN.sub(replace, value)


def _parse_field_mappings(raw_field_mappings: dict[str, Any]) -> dict[str, FieldMapping]:
    if not raw_field_mappings:
        raise ConfigError("field_mappings must contain at least one source column.")

    parsed: dict[str, FieldMapping] = {}
    source_names: set[str] = set()
    target_names: set[str] = set()

    for source_name, raw_mapping in raw_field_mappings.items():
        if not isinstance(source_name, str) or not source_name.strip():
            raise ConfigError("field_mappings keys must be non-empty strings.")
        normalized_source_name = source_name.casefold()
        if normalized_source_name in source_names:
            raise ConfigError(
                f"Duplicate source column mapping detected in field_mappings: {source_name}"
            )
        source_names.add(normalized_source_name)

        if isinstance(raw_mapping, str):
            target_name = _require_identifier(raw_mapping, f"field_mappings.{source_name}")
            description = (
                f"BIAN-aligned alias for source column {source_name}."
            )
            tests: tuple[TestSpec, ...] = ()
        elif isinstance(raw_mapping, dict):
            target_name = _require_identifier(
                raw_mapping.get("target_name"),
                f"field_mappings.{source_name}.target_name",
            )
            description = raw_mapping.get("description")
            if description is None:
                description = f"BIAN-aligned alias for source column {source_name}."
            else:
                description = _require_string(
                    description,
                    f"field_mappings.{source_name}.description",
                )
            tests = _parse_test_specs(
                raw_mapping.get("tests", []),
                f"field_mappings.{source_name}.tests",
            )
        else:
            raise ConfigError(
                f"field_mappings.{source_name} must be a string or an object."
            )

        target_name_key = target_name.casefold()
        if target_name_key in target_names:
            raise ConfigError(
                f"Duplicate BIAN target name detected in field_mappings: {target_name}"
            )

        target_names.add(target_name_key)
        parsed[source_name] = FieldMapping(
            source_name=source_name,
            target_name=target_name,
            description=description,
            tests=tests,
        )

    return parsed


def _parse_test_specs(raw_tests: Any, field_name: str) -> tuple[TestSpec, ...]:
    if not isinstance(raw_tests, list):
        raise ConfigError(f"{field_name} must be a YAML list.")

    parsed_tests: list[TestSpec] = []
    for index, raw_test in enumerate(raw_tests):
        item_name = f"{field_name}[{index}]"
        if isinstance(raw_test, str):
            parsed_tests.append(_require_identifier(raw_test, item_name))
        elif isinstance(raw_test, dict):
            if len(raw_test) != 1:
                raise ConfigError(
                    f"{item_name} must define exactly one dbt test name."
                )
            parsed_tests.append(raw_test)
        else:
            raise ConfigError(
                f"{item_name} must be a string or a one-item YAML object."
            )

    return tuple(parsed_tests)


def _require_dict(value: Any, field_name: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ConfigError(f"{field_name} must be a YAML object.")
    return value


def _require_string(value: Any, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ConfigError(f"{field_name} must be a non-empty string.")
    return value.strip()


def _require_identifier(value: Any, field_name: str) -> str:
    identifier = _require_string(value, field_name)
    if not IDENTIFIER_PATTERN.match(identifier):
        raise ConfigError(
            f"{field_name} must match {IDENTIFIER_PATTERN.pattern}: {identifier}"
        )
    return identifier


def _derive_identifier(value: str, field_name: str) -> str:
    normalized = re.sub(r"[^A-Za-z0-9_]+", "_", value.strip().lower())
    normalized = re.sub(r"^[^A-Za-z_]+", "", normalized)
    normalized = normalized.strip("_")
    if not normalized or not IDENTIFIER_PATTERN.match(normalized):
        raise ConfigError(
            f"Unable to derive a valid identifier for {field_name} from value: {value}"
        )
    return normalized


def _require_positive_int(value: Any, field_name: str) -> int:
    if not isinstance(value, int) or value <= 0:
        raise ConfigError(f"{field_name} must be a positive integer.")
    return value


def _require_bool(value: Any, field_name: str) -> bool:
    if not isinstance(value, bool):
        raise ConfigError(f"{field_name} must be true or false.")
    return value


def _require_materialization(value: Any, field_name: str) -> str:
    materialized = _require_string(value, field_name)
    if materialized not in VALID_MATERIALIZATIONS:
        raise ConfigError(
            f"{field_name} must be one of: " + ", ".join(sorted(VALID_MATERIALIZATIONS))
        )
    return materialized
