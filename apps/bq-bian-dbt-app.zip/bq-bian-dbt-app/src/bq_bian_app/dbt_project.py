from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .bigquery_service import SourceColumn, TableInspection
from .config import FieldMapping, PipelineConfig
from .errors import ConfigError, DbtGenerationError


def generate_dbt_config_files(
    config: PipelineConfig,
    dbt_root: Path,
) -> list[Path]:
    """Write only the config-derived dbt artifacts (dbt_project.yml, profiles.yml).

    Unlike generate_dbt_project, this does not require a BigQuery source-table
    inspection, so it works even when the source table is not reachable yet
    (for example, while the config is still being drafted).
    """
    try:
        dbt_root.mkdir(parents=True, exist_ok=True)
    except OSError as error:
        raise DbtGenerationError(f"Unable to create dbt directory {dbt_root}: {error}") from error

    return [
        _write_yaml(dbt_root / "dbt_project.yml", _build_dbt_project_yaml(config)),
        _write_yaml(dbt_root / "profiles.yml", _build_profiles_yaml(config)),
    ]


def generate_dbt_project(
    config: PipelineConfig,
    inspection: TableInspection,
    dbt_root: Path,
) -> list[Path]:
    selected_columns = _build_selected_columns(config, inspection)

    try:
        dbt_root.mkdir(parents=True, exist_ok=True)
        (dbt_root / "analyses").mkdir(exist_ok=True)
        (dbt_root / "macros").mkdir(exist_ok=True)
        (dbt_root / "models").mkdir(exist_ok=True)
        (dbt_root / "models" / "staging").mkdir(parents=True, exist_ok=True)
        (dbt_root / "models" / "bian").mkdir(parents=True, exist_ok=True)
        (dbt_root / "seeds").mkdir(exist_ok=True)
        (dbt_root / "snapshots").mkdir(exist_ok=True)
        (dbt_root / "tests").mkdir(exist_ok=True)
    except OSError as error:
        raise DbtGenerationError(f"Unable to create dbt directory {dbt_root}: {error}") from error

    written_files = [
        _write_yaml(dbt_root / "dbt_project.yml", _build_dbt_project_yaml(config)),
        _write_yaml(dbt_root / "profiles.yml", _build_profiles_yaml(config)),
        _write_yaml(
            dbt_root / "models" / "sources.yml",
            _build_sources_yaml(config, inspection),
        ),
        _write_text(
            dbt_root / "models" / "staging" / f"{config.dbt.staging_model_name}.sql",
            _build_staging_sql(config, inspection),
        ),
        _write_text(
            dbt_root / "models" / "bian" / f"{config.dbt.bian_model_name}.sql",
            _build_bian_sql(config, selected_columns),
        ),
        _write_yaml(
            dbt_root / "models" / "schema.yml",
            _build_schema_yaml(config, inspection, selected_columns),
        ),
    ]

    return written_files


def _build_selected_columns(
    config: PipelineConfig,
    inspection: TableInspection,
) -> list[tuple[SourceColumn, FieldMapping | None, str]]:
    schema_columns_by_key = {column.name.casefold(): column.name for column in inspection.columns}
    mapping_columns_by_key = {
        source_name.casefold(): source_name for source_name in config.field_mappings
    }

    extra_columns = sorted(
        original_name
        for key, original_name in mapping_columns_by_key.items()
        if key not in schema_columns_by_key
    )
    if extra_columns:
        raise ConfigError(
            "field_mappings contains columns not found in the source table schema: "
            + ", ".join(extra_columns)
        )

    selected_columns: list[tuple[SourceColumn, FieldMapping | None, str]] = []
    used_output_names: dict[str, str] = {}

    for column in inspection.columns:
        mapping_key = mapping_columns_by_key.get(column.name.casefold())
        mapping = config.field_mappings.get(mapping_key) if mapping_key is not None else None
        if mapping is None and not config.bigquery.target.include_unmapped_columns:
            continue

        output_name = mapping.target_name if mapping else column.name
        output_name_key = output_name.casefold()
        if output_name_key in used_output_names:
            raise ConfigError(
                "Duplicate output column name detected during dbt generation: "
                f"{output_name} from {used_output_names[output_name_key]} and {column.name}"
            )
        used_output_names[output_name_key] = column.name
        selected_columns.append((column, mapping, output_name))

    if not selected_columns:
        raise ConfigError("No output columns were selected for the generated BIAN model.")

    return selected_columns


def _build_dbt_project_yaml(config: PipelineConfig) -> dict[str, object]:
    return {
        "name": config.dbt.project_name,
        "version": "1.0.0",
        "config-version": 2,
        "profile": config.dbt.profile_name,
        "model-paths": ["models"],
        "analysis-paths": ["analyses"],
        "test-paths": ["tests"],
        "seed-paths": ["seeds"],
        "macro-paths": ["macros"],
        "snapshot-paths": ["snapshots"],
        "target-path": "target",
        "clean-targets": ["target", "dbt_packages", "logs"],
        "models": {
            config.dbt.project_name: {
                "staging": {
                    "+materialized": config.dbt.staging_materialized,
                },
                "bian": {
                    "+materialized": config.dbt.output_materialized,
                },
            }
        },
    }


def _build_profiles_yaml(config: PipelineConfig) -> dict[str, object]:
    output: dict[str, object] = {
        "type": "bigquery",
        "method": config.auth.method,
        "project": config.bigquery.project_id,
        "dataset": config.bigquery.target.dataset,
        "location": config.bigquery.location,
        "threads": config.dbt.threads,
        "priority": "interactive",
    }

    if config.auth.method == "service-account":
        env_name = config.auth.credentials_path_env
        if not env_name:
            raise DbtGenerationError(
                "Cannot render profiles.yml without auth.credentials_path_env."
            )
        output["keyfile"] = "{{ env_var('" + env_name + "') }}"

    return {
        config.dbt.profile_name: {
            "target": "default",
            "outputs": {
                "default": output,
            },
        }
    }


def _build_sources_yaml(
    config: PipelineConfig,
    inspection: TableInspection,
) -> dict[str, object]:
    return {
        "version": 2,
        "sources": [
            {
                "name": config.dbt.source_name,
                "database": config.bigquery.project_id,
                "schema": config.bigquery.source.dataset,
                "tables": [
                    {
                        "name": config.bigquery.source.table,
                        "description": (
                            "BigQuery source table inspected by bq-bian-app before "
                            "BIAN field-name standardization."
                        ),
                        "columns": [
                            {
                                "name": column.name,
                                "description": _build_source_column_description(column),
                            }
                            for column in inspection.columns
                        ],
                    }
                ],
            }
        ],
    }


def _build_schema_yaml(
    config: PipelineConfig,
    inspection: TableInspection,
    selected_columns: list[tuple[SourceColumn, FieldMapping | None, str]],
) -> dict[str, object]:
    staging_columns = [
        {
            "name": column.name,
            "description": _build_staging_column_description(column),
        }
        for column in inspection.columns
    ]

    bian_columns: list[dict[str, object]] = []
    for column, mapping, output_name in selected_columns:
        column_definition: dict[str, object] = {
            "name": output_name,
            "description": _build_bian_column_description(column, mapping, output_name),
        }
        tests = _build_column_tests(column, mapping)
        if tests:
            column_definition["tests"] = tests
        bian_columns.append(column_definition)

    return {
        "version": 2,
        "models": [
            {
                "name": config.dbt.staging_model_name,
                "description": (
                    "Staging projection of the source table with original source "
                    "field names preserved."
                ),
                "columns": staging_columns,
            },
            {
                "name": config.dbt.bian_model_name,
                "description": (
                    "BIAN-aligned output model that only renames configured source fields "
                    "and otherwise preserves the source shape."
                ),
                "columns": bian_columns,
            },
        ],
    }


def _build_staging_sql(config: PipelineConfig, inspection: TableInspection) -> str:
    select_columns = ",\n".join(
        f"    {_quote_identifier(column.name)}" for column in inspection.columns
    )

    return (
        "{{\n"
        "    config(\n"
        f'        materialized = "{config.dbt.staging_materialized}",\n'
        "    )\n"
        "}}\n\n"
        "select\n"
        f"{select_columns}\n"
        f"from {{{{ source('{config.dbt.source_name}', '{config.bigquery.source.table}') }}}}\n"
    )


def _build_bian_sql(
    config: PipelineConfig,
    selected_columns: list[tuple[SourceColumn, FieldMapping | None, str]],
) -> str:
    select_columns = ",\n".join(
        (
            f"    {_quote_identifier(column.name)} as "
            f"{_quote_identifier(output_name)}"
        )
        for column, _mapping, output_name in selected_columns
    )

    return (
        "{{\n"
        "    config(\n"
        f'        materialized = "{config.dbt.output_materialized}",\n'
        "    )\n"
        "}}\n\n"
        "select\n"
        f"{select_columns}\n"
        f"from {{{{ ref('{config.dbt.staging_model_name}') }}}}\n"
    )


def _build_source_column_description(column: SourceColumn) -> str:
    description = f"{column.field_type} {column.mode} source column."
    if column.description:
        return f"{description} {column.description}"
    return description


def _build_staging_column_description(column: SourceColumn) -> str:
    description = f"Direct projection of source column {column.name}. {column.field_type} {column.mode}."
    if column.description:
        return f"{description} {column.description}"
    return description


def _build_bian_column_description(
    column: SourceColumn,
    mapping: FieldMapping | None,
    output_name: str,
) -> str:
    if mapping is None:
        return (
            f"Passthrough source column {column.name} preserved without renaming. "
            f"Derived from source column {column.name} ({column.field_type} {column.mode})."
        )
    return (
        f"{mapping.description} "
        f"Derived from source column {column.name} as {output_name} "
        f"({column.field_type} {column.mode})."
    )


def _build_column_tests(
    column: SourceColumn,
    mapping: FieldMapping | None,
) -> list[Any]:
    tests = list(mapping.tests if mapping else ())
    if column.mode == "REQUIRED" and not _contains_test_name(tests, "not_null"):
        tests.insert(0, "not_null")
    return tests


def _write_yaml(path: Path, content: dict[str, object]) -> Path:
    rendered = yaml.safe_dump(content, sort_keys=False, allow_unicode=False)
    return _write_text(path, rendered)


def _write_text(path: Path, content: str) -> Path:
    try:
        path.write_text(content, encoding="utf-8")
    except OSError as error:
        raise DbtGenerationError(f"Unable to write {path}: {error}") from error
    return path


def _quote_identifier(name: str) -> str:
    if "`" in name:
        raise DbtGenerationError(
            f"Column names containing backticks are not supported: {name}"
        )
    return f"`{name}`"


def _contains_test_name(tests: list[Any], test_name: str) -> bool:
    for test in tests:
        if isinstance(test, str) and test == test_name:
            return True
        if isinstance(test, dict) and test_name in test:
            return True
    return False
